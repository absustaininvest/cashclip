# Apple Distribution Certificate Credentials

  Use these values in conjunction with your Apple Distribution Certificate files to distribute your iOS app to external users.

  ## Credential Values

  - Apple Distribution Certificate serial number: 7BFAD2C51F464856B1ACD615A5DF0D85
  - Apple Distribution Certificate password: hATsoKtf9RCV45kQ1+qMLg==
  