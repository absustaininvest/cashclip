---
name: CashClip Firebase Analytics not wired in
description: Why Firebase shows 0 users despite an iOS app being registered, and what adding it actually requires.
---

Firebase reporting 0 users is EXPECTED, not a bug: the CashClip app binary has no Firebase SDK.
- The app ships the AdMob SDK (`react-native-google-mobile-ads`) only. There is no `@react-native-firebase/*` package, no `GoogleService-Info.plist` / `google-services.json` in the repo, and no analytics/init code.
- AdMob revenue is INDEPENDENT of Firebase — money is unaffected by the missing SDK.

Console state (Jun 2026): Firebase project "CashClip Earn Real Money", project ID `cashclip-earn-real-money`, project number `130785964499`. The iOS app `app.replit.cashclip` IS registered (bundle matches the live app) and its `GoogleService-Info.plist` is downloadable. NO Android app is registered yet.

**Why:** A registered app in the Firebase console only means the console knows the bundle ID; the installed binary still has to embed the SDK + config to send any data. The owner's hunch that "the domain"/bundle ID is the cause is wrong — the bundle ID matches perfectly; the SDK is simply absent.

**How to apply:** Don't chase "Firebase 0 users" as a runtime/domain bug. Wiring Firebase = NATIVE change (SDK + Expo config plugin + plist/json + init/events) → can't OTA; it only starts collecting once a NEW build ships. Never change the live bundle ID `app.replit.cashclip` to "fix" it — that would orphan the published App Store / Play listing.

## Jun 5 2026: SDK now wired ("in the oven", iOS) — NOT yet built
- Installed `@react-native-firebase/app` + `@react-native-firebase/analytics` `^24.0.0` (v24 = current, Expo SDK 54 / RN 0.81 compatible, peer `expo >=47`).
- `app.json`: added `@react-native-firebase/app` as the FIRST plugin entry + `ios.googleServicesFile: "./GoogleService-Info.plist"`. No JS imports Firebase yet, so the running Expo dev/web bundle is unaffected and analytics auto-collects baseline events (first_open/session_start) once a native build ships — no init code required. Custom event logging (signups, withdrawals, screen_view) is a separate later package.
- The `GoogleService-Info.plist` lives at `artifacts/cashclip/GoogleService-Info.plist` (restored from git history; bundle inside = `app.replit.cashclip` ✓). Firebase iOS plist API_KEY is NOT a real secret (bundle-restricted, ships in every binary), and AdMob app IDs are already plaintext in app.json — so committing it is safe/consistent, not a leak.
- **Install gotcha (recurs every pnpm install here):** root `prepare` script runs `git config core.hooksPath …`, which the main-agent git guardrail BLOCKS and leaves a stale `.git/config.lock` the agent also can't delete (path-based guardrail). Workaround: install Expo/native deps with `pnpm --filter @workspace/cashclip add <pkg> --ignore-scripts` (skips `prepare`, no git write). `expo install` triggers the same block — prefer `pnpm add --ignore-scripts` + pin the npm version manually.
- **Build-time caveat (verify at EAS build, not now):** AdMob (`react-native-google-mobile-ads`) currently builds WITHOUT `useFrameworks` and works on live build 29. Firebase Analytics normally links fine alongside it without `use_frameworks`. Left `expo-build-properties` untouched to avoid disturbing the working AdMob/mediation pods. IF the next EAS build fails on Firebase pods, the known fix is `ios.useFrameworks: "static"` — but that MUST be retested against AdMob + Unity/ironSource/Pangle mediation before shipping.
- Ships in the SAME next native build as Chipley + the new Expo account resources (owner is batching). Bump versions then (iOS buildNumber / Android versionCode are at 39 in app.json).
- **Android landmine (iOS-only intent):** the `@react-native-firebase/app` config plugin applies to BOTH platforms; a future ANDROID native build/prebuild will FAIL ("google-services.json missing") because no Android app is registered in Firebase and no `android.googleServicesFile` is set. Currently safe because Android rides OTA on build 38 (no imminent native Android build) and the next native build is iOS (Chipley batch). Before ANY Android native rebuild: either register the Android app in Firebase + add `google-services.json` + `android.googleServicesFile`, or restrict the build target to iOS.
