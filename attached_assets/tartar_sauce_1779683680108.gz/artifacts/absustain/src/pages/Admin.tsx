import { useState, useEffect, useRef, useCallback } from "react";
import type { LucideIcon } from "lucide-react";
import {
  LogOut, Filter, RefreshCw, Mail, User, Calendar, Tag, Plus, Trash2, Check, Clock,
  TrendingUp, Users, MessageSquare, Bell, ChevronRight, ExternalLink,
  Upload, FileText, Download, X, BookOpen, Calculator, Layers, AlertCircle,
  Linkedin, Instagram, Facebook, Youtube, ShoppingCart, Copy, Music2,
  Globe, Smartphone, Palette, Share2, Package, BarChart3, KeyRound, Eye, EyeOff,
  Inbox, AtSign, Building2, Megaphone, Headphones,
} from "lucide-react";

interface Lead {
  id: string;
  name: string;
  email: string;
  message?: string;
  type: string;
  source: string;
  createdAt: string;
}

interface Reminder {
  id: string;
  text: string;
  done: boolean;
  createdAt: string;
}

interface VentureFile {
  id: string;
  originalName: string;
  storedName: string;
  category: string;
  description: string;
  size: number;
  mimeType: string;
  uploadedAt: string;
}

const VENTURE_CATEGORIES = [
  "Restaurant Proposals",
  "Menus",
  "Location Analysis",
  "Financial Projections",
  "Permits & Licenses",
  "Supplier Agreements",
  "Floor Plans",
  "Photos",
  "General",
];

function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function fileIcon(mime: string): string {
  if (mime === "application/pdf") return "🗒️";
  if (mime.startsWith("image/")) return "🖼️";
  if (mime.includes("spreadsheet") || mime.includes("excel") || mime === "text/csv") return "📊";
  if (mime.includes("word") || mime.includes("document")) return "📄";
  if (mime === "application/zip") return "🗜️";
  return "📎";
}

function LoginForm({ onLogin }: { onLogin: (token: string) => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function doLogin(user: string, pass: string) {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: user, password: pass }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Login failed");
      if (data.user.role !== "admin") throw new Error("Admin access required");
      localStorage.setItem("admin_token", data.token);
      onLogin(data.token);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    doLogin(username, password);
  }

  return (
    <div className="min-h-screen bg-[#06060E] flex items-center justify-center p-6">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <img src={`${import.meta.env.BASE_URL}logo-full.png`} alt="AB Sustainability" className="h-12 rounded mx-auto mb-4" />
          <h1 className="font-['Space_Grotesk'] text-2xl font-bold text-white">Admin Dashboard</h1>
          <p className="text-white/40 text-sm mt-2">Sign in to manage your business</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Username"
            required
            className="w-full bg-white/[0.05] border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-[#00E676]/50 transition-colors"
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            required
            className="w-full bg-white/[0.05] border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-[#00E676]/50 transition-colors"
          />
          {error && <p className="text-red-400 text-sm text-center">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#00E676] text-[#06060E] font-bold py-3 rounded-xl hover:bg-[#00E676]/90 transition-colors disabled:opacity-50"
          >
            {loading ? "Signing in..." : "Sign In"}
          </button>
        </form>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }: { icon: LucideIcon; label: string; value: number; color: string }) {
  return (
    <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-5 hover:border-white/[0.12] transition-colors">
      <div className="flex items-center justify-between mb-3">
        <div className={`p-2.5 rounded-xl ${color}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
      <p className="font-['Space_Grotesk'] text-3xl font-bold text-white">{value}</p>
      <p className="text-white/40 text-sm mt-1">{label}</p>
    </div>
  );
}

function MiniCalendar() {
  const now = new Date();
  const month = now.toLocaleString("en-US", { month: "long", year: "numeric" });
  const today = now.getDate();
  const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).getDay();
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();

  const days: (number | null)[] = [];
  for (let i = 0; i < firstDay; i++) days.push(null);
  for (let i = 1; i <= daysInMonth; i++) days.push(i);

  return (
    <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <Calendar className="w-4 h-4 text-[#00E676]" />
        <h3 className="font-['Space_Grotesk'] font-bold text-white text-sm">{month}</h3>
      </div>
      <div className="grid grid-cols-7 gap-1 text-center text-xs">
        {["S","M","T","W","T","F","S"].map((d, i) => (
          <div key={i} className="text-white/30 font-medium py-1">{d}</div>
        ))}
        {days.map((d, i) => (
          <div key={i} className={`py-1.5 rounded-lg transition-colors ${
            d === today ? "bg-[#00E676] text-[#06060E] font-bold"
              : d ? "text-white/60 hover:bg-white/[0.05] cursor-default" : ""
          }`}>
            {d}
          </div>
        ))}
      </div>
    </div>
  );
}

function RemindersPanel() {
  const [reminders, setReminders] = useState<Reminder[]>(() => {
    const saved = localStorage.getItem("admin_reminders");
    return saved ? JSON.parse(saved) : [];
  });
  const [newText, setNewText] = useState("");

  useEffect(() => {
    localStorage.setItem("admin_reminders", JSON.stringify(reminders));
  }, [reminders]);

  function addReminder() {
    if (!newText.trim()) return;
    setReminders([
      { id: Date.now().toString(), text: newText.trim(), done: false, createdAt: new Date().toISOString() },
      ...reminders,
    ]);
    setNewText("");
  }

  function toggleReminder(id: string) {
    setReminders(reminders.map((r) => (r.id === id ? { ...r, done: !r.done } : r)));
  }

  function deleteReminder(id: string) {
    setReminders(reminders.filter((r) => r.id !== id));
  }

  return (
    <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <Bell className="w-4 h-4 text-amber-400" />
        <h3 className="font-['Space_Grotesk'] font-bold text-white text-sm">Reminders</h3>
        <span className="ml-auto text-white/30 text-xs">{reminders.filter((r) => !r.done).length} active</span>
      </div>
      <div className="flex gap-2 mb-3">
        <input
          type="text"
          value={newText}
          onChange={(e) => setNewText(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && addReminder()}
          placeholder="Add a reminder..."
          className="flex-1 bg-white/[0.05] border border-white/10 rounded-lg px-3 py-2 text-white text-sm placeholder-white/30 focus:outline-none focus:border-[#00E676]/50 transition-colors"
        />
        <button onClick={addReminder} className="p-2 bg-[#00E676]/10 text-[#00E676] rounded-lg hover:bg-[#00E676]/20 transition-colors">
          <Plus className="w-4 h-4" />
        </button>
      </div>
      <div className="space-y-1.5 max-h-48 overflow-y-auto">
        {reminders.length === 0 ? (
          <p className="text-white/20 text-xs text-center py-4">No reminders yet</p>
        ) : (
          reminders.map((r) => (
            <div key={r.id} className="flex items-center gap-2 group">
              <button
                onClick={() => toggleReminder(r.id)}
                className={`w-5 h-5 rounded-md border flex-shrink-0 flex items-center justify-center transition-colors ${
                  r.done ? "bg-[#00E676]/20 border-[#00E676]/40 text-[#00E676]" : "border-white/20 hover:border-white/40"
                }`}
              >
                {r.done && <Check className="w-3 h-3" />}
              </button>
              <span className={`text-sm flex-1 ${r.done ? "text-white/30 line-through" : "text-white/70"}`}>{r.text}</span>
              <button onClick={() => deleteReminder(r.id)} className="opacity-0 group-hover:opacity-100 text-white/20 hover:text-red-400 transition-all">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function QuickActions() {
  const actions = [
    { label: "Email Support Inbox", href: "mailto:support@absustaininvest.com", icon: Mail, color: "text-blue-400" },
    { label: "CashClip Support", href: "mailto:support@absustaininvest.com", icon: Mail, color: "text-purple-400" },
    { label: "CashClip App", href: "https://cash-clip.app", icon: ExternalLink, color: "text-[#00E676]" },
    { label: "AB Sustainability Site", href: "https://absustaininvest.com", icon: ExternalLink, color: "text-amber-400" },
  ];
  return (
    <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <MessageSquare className="w-4 h-4 text-blue-400" />
        <h3 className="font-['Space_Grotesk'] font-bold text-white text-sm">Quick Actions</h3>
      </div>
      <div className="space-y-1">
        {actions.map((a) => (
          <a
            key={a.label}
            href={a.href}
            target={a.href.startsWith("http") ? "_blank" : undefined}
            rel={a.href.startsWith("http") ? "noopener noreferrer" : undefined}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/[0.05] transition-colors group"
          >
            <a.icon className={`w-4 h-4 ${a.color}`} />
            <span className="text-white/60 text-sm group-hover:text-white transition-colors flex-1">{a.label}</span>
            <ChevronRight className="w-3.5 h-3.5 text-white/20 group-hover:text-white/40 transition-colors" />
          </a>
        ))}
      </div>
    </div>
  );
}

function VenturesPanel({ token }: { token: string }) {
  const [files, setFiles] = useState<VentureFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const [uploadSuccess, setUploadSuccess] = useState("");
  const [category, setCategory] = useState("Restaurant Proposals");
  const [description, setDescription] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function fetchFiles() {
    setLoading(true);
    try {
      const res = await fetch("/api/ventures/files", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) setFiles(await res.json());
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { fetchFiles(); }, []);

  async function handleUpload(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedFile) return;
    setUploading(true);
    setUploadError("");
    setUploadSuccess("");
    try {
      const formData = new FormData();
      formData.append("file", selectedFile);
      formData.append("category", category);
      formData.append("description", description);
      const res = await fetch("/api/ventures/files", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Upload failed");
      setUploadSuccess(`"${selectedFile.name}" uploaded successfully.`);
      setSelectedFile(null);
      setDescription("");
      if (fileInputRef.current) fileInputRef.current.value = "";
      await fetchFiles();
    } catch (err: any) {
      setUploadError(err.message);
    } finally {
      setUploading(false);
    }
  }

  async function handleDelete(id: string, name: string) {
    if (!confirm(`Delete "${name}"? This cannot be undone.`)) return;
    setDeletingId(id);
    try {
      await fetch(`/api/ventures/files/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      setFiles((f) => f.filter((x) => x.id !== id));
    } finally {
      setDeletingId(null);
    }
  }

  const byCategory = files.reduce<Record<string, VentureFile[]>>((acc, f) => {
    (acc[f.category] ??= []).push(f);
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-['Space_Grotesk'] text-xl font-bold text-white">Solera — Food Service Files</h2>
          <p className="text-white/40 text-sm mt-1">Upload restaurant files, proposals, and resources for the Ventures page.</p>
        </div>
        <span className="text-white/30 text-sm">{files.length} {files.length === 1 ? "file" : "files"}</span>
      </div>

      {/* Upload form */}
      <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-6">
        <div className="flex items-center gap-2 mb-5">
          <Upload className="w-4 h-4 text-[#00E676]" />
          <h3 className="font-['Space_Grotesk'] font-bold text-white text-sm">Upload New File</h3>
        </div>
        <form onSubmit={handleUpload} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-white/40 text-xs mb-1.5">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-white/[0.05] border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-[#00E676]/50 transition-colors"
              >
                {VENTURE_CATEGORIES.map((c) => (
                  <option key={c} value={c} className="bg-[#06060E]">{c}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-white/40 text-xs mb-1.5">Description (optional)</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Brief description..."
                className="w-full bg-white/[0.05] border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm placeholder-white/30 focus:outline-none focus:border-[#00E676]/50 transition-colors"
              />
            </div>
          </div>
          <div>
            <label className="block text-white/40 text-xs mb-1.5">File (PDF, images, Excel, Word, CSV — max 50 MB)</label>
            <div
              className="border-2 border-dashed border-white/10 rounded-xl p-6 text-center hover:border-[#00E676]/30 transition-colors cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
            >
              {selectedFile ? (
                <div className="flex items-center justify-center gap-3">
                  <span className="text-2xl">{fileIcon(selectedFile.type)}</span>
                  <div className="text-left">
                    <p className="text-white text-sm font-medium">{selectedFile.name}</p>
                    <p className="text-white/40 text-xs">{formatSize(selectedFile.size)}</p>
                  </div>
                  <button
                    type="button"
                    onClick={(e) => { e.stopPropagation(); setSelectedFile(null); if (fileInputRef.current) fileInputRef.current.value = ""; }}
                    className="ml-2 text-white/30 hover:text-red-400 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div>
                  <Upload className="w-8 h-8 text-white/20 mx-auto mb-2" />
                  <p className="text-white/40 text-sm">Click to choose a file</p>
                  <p className="text-white/20 text-xs mt-1">or drag and drop</p>
                </div>
              )}
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept=".pdf,.jpg,.jpeg,.png,.gif,.webp,.xls,.xlsx,.doc,.docx,.csv,.txt,.zip"
                onChange={(e) => setSelectedFile(e.target.files?.[0] ?? null)}
              />
            </div>
          </div>
          {uploadError && (
            <div className="flex items-center gap-2 text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              {uploadError}
            </div>
          )}
          {uploadSuccess && (
            <div className="flex items-center gap-2 text-[#00E676] text-sm bg-[#00E676]/10 border border-[#00E676]/20 rounded-xl px-4 py-3">
              <Check className="w-4 h-4 flex-shrink-0" />
              {uploadSuccess}
            </div>
          )}
          <button
            type="submit"
            disabled={!selectedFile || uploading}
            className="bg-[#00E676] text-[#06060E] font-bold px-6 py-2.5 rounded-xl hover:bg-[#00E676]/90 transition-colors disabled:opacity-40 disabled:cursor-not-allowed text-sm"
          >
            {uploading ? "Uploading..." : "Upload File"}
          </button>
        </form>
      </div>

      {/* File list */}
      <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl overflow-hidden">
        <div className="flex items-center gap-2 px-5 py-4 border-b border-white/[0.06]">
          <FileText className="w-4 h-4 text-white/40" />
          <h3 className="font-['Space_Grotesk'] font-bold text-white text-sm">Uploaded Files</h3>
          <button onClick={fetchFiles} className="ml-auto text-white/30 hover:text-white transition-colors">
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          </button>
        </div>
        {loading ? (
          <div className="text-center py-12 text-white/30 text-sm">Loading files...</div>
        ) : files.length === 0 ? (
          <div className="text-center py-12">
            <FileText className="w-10 h-10 text-white/10 mx-auto mb-3" />
            <p className="text-white/30 text-sm">No files uploaded yet</p>
            <p className="text-white/20 text-xs mt-1">Use the form above to upload your first file</p>
          </div>
        ) : (
          <div className="divide-y divide-white/[0.04]">
            {Object.entries(byCategory).map(([cat, catFiles]) => (
              <div key={cat}>
                <div className="px-5 py-2 bg-white/[0.02]">
                  <span className="text-white/40 text-xs font-semibold uppercase tracking-wider">{cat}</span>
                </div>
                {catFiles.map((f) => (
                  <div key={f.id} className="flex items-center gap-3 px-5 py-3.5 hover:bg-white/[0.02] transition-colors group">
                    <span className="text-xl flex-shrink-0">{fileIcon(f.mimeType)}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm font-medium truncate">{f.originalName}</p>
                      <div className="flex items-center gap-3 mt-0.5">
                        <span className="text-white/30 text-xs">{formatSize(f.size)}</span>
                        {f.description && <span className="text-white/30 text-xs truncate">• {f.description}</span>}
                        <span className="text-white/20 text-xs">
                          {new Date(f.uploadedAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <button
                        onClick={async () => {
                          const res = await fetch(`/api/ventures/files/${f.id}`, {
                            headers: { Authorization: `Bearer ${token}` },
                          });
                          if (!res.ok) return;
                          const blob = await res.blob();
                          const url = URL.createObjectURL(blob);
                          const a = document.createElement("a");
                          a.href = url;
                          a.download = f.originalName;
                          a.click();
                          URL.revokeObjectURL(url);
                        }}
                        className="flex items-center gap-1.5 text-[#00E676]/60 hover:text-[#00E676] transition-colors text-xs"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span className="hidden sm:block">Download</span>
                      </button>
                      <button
                        onClick={() => handleDelete(f.id, f.originalName)}
                        disabled={deletingId === f.id}
                        className="opacity-0 group-hover:opacity-100 text-white/20 hover:text-red-400 transition-all disabled:opacity-50"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function AccountingPanel() {
  const links = [
    {
      label: "Zoho Books",
      description: "Accounting, invoices & financial reports",
      href: "https://books.zoho.com",
      icon: BookOpen,
      color: "text-[#00E676]",
      bg: "bg-[#00E676]/10 border-[#00E676]/20",
    },
    {
      label: "Zoho Mail",
      description: "Business email — absustaininvest.com",
      href: "https://mail.zoho.com",
      icon: Mail,
      color: "text-blue-400",
      bg: "bg-blue-500/10 border-blue-500/20",
    },
    {
      label: "Zoho CRM",
      description: "Customer & partner relationship management",
      href: "https://crm.zoho.com",
      icon: Users,
      color: "text-purple-400",
      bg: "bg-purple-500/10 border-purple-500/20",
    },
    {
      label: "Zoho Analytics",
      description: "Business intelligence & reporting",
      href: "https://analytics.zoho.com",
      icon: TrendingUp,
      color: "text-amber-400",
      bg: "bg-amber-500/10 border-amber-500/20",
    },
  ];

  const domainConfig = [
    { label: "Domain", value: "absustaininvest.com", status: "Verified" },
    { label: "MX Records", value: "mx.zoho.com", status: "Active" },
    { label: "SPF", value: "include:zohomail.com ~all", status: "Configured" },
    { label: "DKIM", value: "default._domainkey", status: "Configured" },
    { label: "DMARC", value: "p=reject; pct=100", status: "Configured" },
    { label: "Solera Subdomain", value: "solera-restaurant.absustaininvest.com", status: "Active" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-['Space_Grotesk'] text-xl font-bold text-white">Accounting & Business Tools</h2>
        <p className="text-white/40 text-sm mt-1">Zoho suite for AB Sustainability Investments LLC — EIN 39-2640135</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {links.map((item) => (
          <a
            key={item.label}
            href={item.href}
            target="_blank"
            rel="noopener noreferrer"
            className={`flex items-start gap-4 p-5 rounded-2xl border bg-white/[0.02] hover:bg-white/[0.04] transition-colors group`}
          >
            <div className={`p-3 rounded-xl border ${item.bg}`}>
              <item.icon className={`w-5 h-5 ${item.color}`} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-['Space_Grotesk'] font-bold text-white text-sm">{item.label}</span>
                <ExternalLink className="w-3 h-3 text-white/20 group-hover:text-white/40 transition-colors" />
              </div>
              <p className="text-white/40 text-xs mt-0.5">{item.description}</p>
            </div>
          </a>
        ))}
      </div>

      <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl overflow-hidden">
        <div className="flex items-center gap-2 px-5 py-4 border-b border-white/[0.06]">
          <Calculator className="w-4 h-4 text-[#00E676]" />
          <h3 className="font-['Space_Grotesk'] font-bold text-white text-sm">Domain & Email Configuration</h3>
          <span className="ml-auto text-[#00E676] text-xs font-medium">All systems active</span>
        </div>
        <div className="divide-y divide-white/[0.04]">
          {domainConfig.map((row) => (
            <div key={row.label} className="flex items-center justify-between px-5 py-3.5">
              <div>
                <span className="text-white/60 text-sm">{row.label}</span>
                <p className="text-white/30 text-xs mt-0.5 font-mono">{row.value}</p>
              </div>
              <span className="text-[#00E676] text-xs font-semibold bg-[#00E676]/10 px-2.5 py-1 rounded-full border border-[#00E676]/20">
                {row.status}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <Layers className="w-4 h-4 text-amber-400" />
          <h3 className="font-['Space_Grotesk'] font-bold text-white text-sm">Entity Information</h3>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {[
            { label: "Entity Name", value: "AB Sustainability Investments LLC" },
            { label: "EIN", value: "39-2640135" },
            { label: "State", value: "Georgia, USA" },
            { label: "D-U-N-S", value: "Certified" },
            { label: "Accounting Software", value: "Zoho Books" },
            { label: "Fiscal Year", value: "Calendar Year" },
          ].map((item) => (
            <div key={item.label}>
              <p className="text-white/30 text-xs">{item.label}</p>
              <p className="text-white text-sm font-medium mt-0.5">{item.value}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function TikTokIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34V8.87a8.16 8.16 0 0 0 4.78 1.52V7a4.85 4.85 0 0 1-1.01-.31z"/>
    </svg>
  );
}

interface SocialPlatform {
  name: string;
  handle: string;
  followers?: string;
  posts?: string;
  status: "Live" | "Needs Rebrand" | "Planned";
  profileUrl: string;
  dashboardUrl: string;
  analyticsUrl: string;
  bio: string;
  color: string;
  bg: string;
  Icon: LucideIcon | null;
}

function IntegrationsPanel() {
  const [copied, setCopied] = useState<string | null>(null);

  function copyToClipboard(key: string, text: string) {
    navigator.clipboard.writeText(text).catch(() => {});
    setCopied(key);
    setTimeout(() => setCopied(null), 2500);
  }

  const socials: SocialPlatform[] = [
    {
      name: "LinkedIn",
      handle: "ab-sustainability-investments",
      followers: "Building",
      status: "Live",
      profileUrl: "https://www.linkedin.com/company/ab-sustainability-investments",
      dashboardUrl: "https://www.linkedin.com/analytics/",
      analyticsUrl: "https://www.linkedin.com/analytics/",
      color: "text-blue-400",
      bg: "bg-blue-500/10 border-blue-500/20",
      Icon: Linkedin,
      bio: `AB Sustainability Investments LLC | Building Real Businesses That Last

A diversified holding company building ventures across technology, retail, and food service.

What we're building:
🟢 CashClip — a mobile rewards app that pays users for everyday actions (live on the App Store)
🟢 Solera — modern restaurant concept rooted in hospitality and quality
🟢 AB Sustainability Investments — the parent holding company, D-U-N-S certified, registered LLC

📩 support@absustaininvest.com
🌐 absustaininvest.com
📱 cash-clip.app`,
    },
    {
      name: "Instagram",
      handle: "@absustaininvest",
      followers: "Building",
      status: "Live",
      profileUrl: "https://www.instagram.com/absustaininvest",
      dashboardUrl: "https://business.instagram.com/",
      analyticsUrl: "https://www.instagram.com/absustaininvest/insights/",
      color: "text-pink-400",
      bg: "bg-pink-500/10 border-pink-500/20",
      Icon: Instagram,
      bio: `🌱 Founder @ AB Sustainability Investments LLC
📱 Creator of CashClip — earn rewards on iOS
🎓 Cornell Dyson | ATL
👇 Ventures + links`,
    },
    {
      name: "Facebook",
      handle: "Andres Ballen",
      followers: "3.7K",
      status: "Live",
      profileUrl: "https://www.facebook.com/share/18uU8mCfPo",
      dashboardUrl: "https://www.facebook.com/creatorstudio",
      analyticsUrl: "https://www.facebook.com/share/18uU8mCfPo",
      color: "text-blue-500",
      bg: "bg-blue-600/10 border-blue-600/20",
      Icon: Facebook,
      bio: `AB Sustainability Investments Holdings LLC — a diversified holding company building ventures across technology, retail, and food service.

🟢 CashClip — mobile rewards app (iOS)
🟢 Solera — modern restaurant concept
🟢 AB Sustainability Investments — D-U-N-S certified parent company

🌐 absustaininvest.com
📩 support@absustaininvest.com`,
    },
    {
      name: "YouTube",
      handle: "@absustaininvest",
      status: "Needs Rebrand",
      profileUrl: "https://www.youtube.com/@absustaininvest",
      dashboardUrl: "https://studio.youtube.com/",
      analyticsUrl: "https://studio.youtube.com/channel/analytics",
      color: "text-red-400",
      bg: "bg-red-500/10 border-red-500/20",
      Icon: Youtube,
      bio: `AB Sustainability Investments — Building sustainable technology, retail, and food service ventures that create real value.

🟢 CashClip — earn cash rewards on your phone (iOS)
🟢 Solera — modern restaurant concept

🌐 absustaininvest.com | 📩 support@absustaininvest.com`,
    },
    {
      name: "TikTok",
      handle: "@cashclipapp",
      status: "Planned",
      profileUrl: "https://www.tiktok.com/@cashclipapp",
      dashboardUrl: "https://creator.tiktok.com/",
      analyticsUrl: "https://creator.tiktok.com/",
      color: "text-white",
      bg: "bg-white/10 border-white/20",
      Icon: null,
      bio: `📱 CashClip — Earn real cash on iOS
💰 Surveys • Videos • Offers • Referrals
💸 Cash out via PayPal
👇 Download free on the App Store`,
    },
  ];

  const appHubs = [
    {
      name: "App Store Connect",
      description: "CashClip • ASC ID 6759931285 • Team FAX932PG78",
      href: "https://appstoreconnect.apple.com",
      icon: Smartphone,
      color: "text-blue-400",
      bg: "bg-blue-500/10 border-blue-500/20",
      badge: "iOS Live",
    },
    {
      name: "Expo EAS Dashboard",
      description: "Build, submit, and OTA update CashClip",
      href: "https://expo.dev",
      icon: Package,
      color: "text-purple-400",
      bg: "bg-purple-500/10 border-purple-500/20",
      badge: "Build CI",
    },
    {
      name: "TestFlight",
      description: "Internal & external beta testing",
      href: "https://appstoreconnect.apple.com/apps/6759931285/testflight",
      icon: BarChart3,
      color: "text-green-400",
      bg: "bg-green-500/10 border-green-500/20",
      badge: "Beta",
    },
    {
      name: "Google Play Console",
      description: "Android release — future expansion",
      href: "https://play.google.com/console",
      icon: Globe,
      color: "text-yellow-400",
      bg: "bg-yellow-500/10 border-yellow-500/20",
      badge: "Coming",
    },
  ];

  const mgmtTools = [
    {
      name: "Buffer",
      description: "Schedule posts to LinkedIn, Instagram, Facebook, TikTok at once",
      href: "https://buffer.com",
      icon: Share2,
      color: "text-[#00E676]",
      bg: "bg-[#00E676]/10 border-[#00E676]/20",
    },
    {
      name: "Meta Business Suite",
      description: "Manage Facebook + Instagram posts, ads, and analytics together",
      href: "https://business.facebook.com",
      icon: Facebook,
      color: "text-blue-400",
      bg: "bg-blue-500/10 border-blue-500/20",
    },
    {
      name: "YouTube Studio",
      description: "Upload, schedule, and analyze YouTube content",
      href: "https://studio.youtube.com",
      icon: Youtube,
      color: "text-red-400",
      bg: "bg-red-500/10 border-red-500/20",
    },
    {
      name: "Canva",
      description: "Design social graphics, menus, and brand materials",
      href: "https://www.canva.com",
      icon: Palette,
      color: "text-pink-400",
      bg: "bg-pink-500/10 border-pink-500/20",
    },
  ];

  const statusColor: Record<SocialPlatform["status"], string> = {
    Live: "text-[#00E676] bg-[#00E676]/10 border-[#00E676]/20",
    "Needs Rebrand": "text-amber-400 bg-amber-500/10 border-amber-500/20",
    Planned: "text-white/40 bg-white/5 border-white/10",
  };

  return (
    <div className="space-y-10">
      <div>
        <h2 className="font-['Space_Grotesk'] text-xl font-bold text-white">Integrations & Hubs</h2>
        <p className="text-white/40 text-sm mt-1">Every platform you need to run AB Sustainability Investments — in one place.</p>
      </div>

      {/* ── Social Media Hub ── */}
      <section>
        <div className="flex items-center gap-2 mb-5">
          <Share2 className="w-4 h-4 text-pink-400" />
          <h3 className="font-['Space_Grotesk'] font-bold text-white">Social Media Hub</h3>
          <span className="ml-auto text-white/30 text-xs">3 live • 1 needs rebrand • 1 planned</span>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {socials.map((s) => (
            <div key={s.name} className={`rounded-2xl border bg-white/[0.02] p-5 space-y-4`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-2.5 rounded-xl border ${s.bg}`}>
                    {s.Icon ? (
                      <s.Icon className={`w-4 h-4 ${s.color}`} />
                    ) : (
                      <TikTokIcon className={`w-4 h-4 ${s.color}`} />
                    )}
                  </div>
                  <div>
                    <p className="font-['Space_Grotesk'] font-bold text-white text-sm">{s.name}</p>
                    <p className="text-white/40 text-xs">{s.handle}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {s.followers && (
                    <span className="text-white/30 text-xs hidden sm:block">{s.followers} followers</span>
                  )}
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${statusColor[s.status]}`}>
                    {s.status}
                  </span>
                </div>
              </div>

              {/* Bio copy block */}
              <div className="bg-white/[0.03] rounded-xl border border-white/[0.06] p-3 relative group">
                <p className="text-white/50 text-xs leading-relaxed whitespace-pre-line line-clamp-4">{s.bio}</p>
                <button
                  onClick={() => copyToClipboard(s.name, s.bio)}
                  className="absolute top-2 right-2 p-1.5 rounded-lg bg-white/[0.05] text-white/30 hover:text-white hover:bg-white/[0.1] transition-colors"
                  title="Copy bio"
                >
                  {copied === s.name ? <Check className="w-3 h-3 text-[#00E676]" /> : <Copy className="w-3 h-3" />}
                </button>
                {copied === s.name && (
                  <span className="absolute bottom-2 right-2 text-[#00E676] text-[10px] font-medium">Copied!</span>
                )}
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 flex-wrap">
                <a
                  href={s.profileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border ${s.bg} ${s.color} hover:opacity-80 transition-opacity`}
                >
                  <ExternalLink className="w-3 h-3" />
                  Open Profile
                </a>
                <a
                  href={s.dashboardUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-white/[0.05] border border-white/10 text-white/60 hover:text-white transition-colors"
                >
                  <BarChart3 className="w-3 h-3" />
                  Dashboard
                </a>
                <button
                  onClick={() => copyToClipboard(`btn-${s.name}`, s.bio)}
                  className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-white/[0.05] border border-white/10 text-white/60 hover:text-white transition-colors ml-auto"
                >
                  {copied === `btn-${s.name}` ? <Check className="w-3 h-3 text-[#00E676]" /> : <Copy className="w-3 h-3" />}
                  {copied === `btn-${s.name}` ? "Copied!" : "Copy Bio"}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── App Distribution Hub ── */}
      <section>
        <div className="flex items-center gap-2 mb-5">
          <Smartphone className="w-4 h-4 text-blue-400" />
          <h3 className="font-['Space_Grotesk'] font-bold text-white">App Distribution Hub</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {appHubs.map((item) => (
            <a
              key={item.name}
              href={item.href}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-start gap-4 p-4 rounded-2xl border bg-white/[0.02] hover:bg-white/[0.04] transition-colors group"
            >
              <div className={`p-2.5 rounded-xl border ${item.bg} flex-shrink-0`}>
                <item.icon className={`w-4 h-4 ${item.color}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-['Space_Grotesk'] font-bold text-white text-sm">{item.name}</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${item.bg} ${item.color}`}>
                    {item.badge}
                  </span>
                  <ExternalLink className="w-3 h-3 text-white/20 group-hover:text-white/40 ml-auto flex-shrink-0" />
                </div>
                <p className="text-white/40 text-xs mt-0.5">{item.description}</p>
              </div>
            </a>
          ))}
        </div>
      </section>

      {/* ── Business Procurement ── */}
      <section>
        <div className="flex items-center gap-2 mb-5">
          <ShoppingCart className="w-4 h-4 text-amber-400" />
          <h3 className="font-['Space_Grotesk'] font-bold text-white">Business Procurement</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <a
            href="https://business.amazon.com"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-start gap-4 p-5 rounded-2xl border border-amber-500/20 bg-amber-500/5 hover:bg-amber-500/10 transition-colors group"
          >
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 flex-shrink-0">
              <ShoppingCart className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-['Space_Grotesk'] font-bold text-white">Amazon Business</span>
                <ExternalLink className="w-3 h-3 text-white/20 group-hover:text-amber-400 transition-colors" />
              </div>
              <p className="text-white/40 text-xs mt-1">B2B purchasing for Solera restaurant supplies, office equipment, and business essentials. Tax-exempt purchasing, bulk pricing, and business analytics.</p>
              <div className="flex flex-wrap gap-1.5 mt-3">
                {["Restaurant Supplies", "Office", "Technology", "Tax-Exempt"].map((tag) => (
                  <span key={tag} className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 font-medium">{tag}</span>
                ))}
              </div>
            </div>
          </a>
          <a
            href="https://www.costcobusinessdelivery.com"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-start gap-4 p-5 rounded-2xl border border-white/[0.06] bg-white/[0.02] hover:bg-white/[0.04] transition-colors group"
          >
            <div className="p-3 rounded-xl bg-white/[0.05] border border-white/[0.1] flex-shrink-0">
              <Package className="w-5 h-5 text-white/50" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-['Space_Grotesk'] font-bold text-white">Costco Business Delivery</span>
                <ExternalLink className="w-3 h-3 text-white/20 group-hover:text-white/40 transition-colors" />
              </div>
              <p className="text-white/40 text-xs mt-1">Wholesale bulk purchasing for food service — ideal for Solera restaurant operations. No membership required for business delivery.</p>
              <div className="flex flex-wrap gap-1.5 mt-3">
                {["Food Service", "Bulk", "Wholesale", "Solera"].map((tag) => (
                  <span key={tag} className="text-[10px] px-2 py-0.5 rounded-full bg-white/[0.05] border border-white/[0.1] text-white/40 font-medium">{tag}</span>
                ))}
              </div>
            </div>
          </a>
          <a
            href="https://www.samsclub.com/b/business"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-start gap-4 p-5 rounded-2xl border border-blue-500/20 bg-blue-500/5 hover:bg-blue-500/10 transition-colors group"
          >
            <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 flex-shrink-0">
              <Package className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-['Space_Grotesk'] font-bold text-white">Sam's Club Business</span>
                <ExternalLink className="w-3 h-3 text-white/20 group-hover:text-blue-400 transition-colors" />
              </div>
              <p className="text-white/40 text-xs mt-1">Membership-based wholesale for business supplies, food service inventory, and bulk essentials. Competitive pricing on high-volume purchases.</p>
              <div className="flex flex-wrap gap-1.5 mt-3">
                {["Wholesale", "Bulk", "Food Service", "Membership"].map((tag) => (
                  <span key={tag} className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 font-medium">{tag}</span>
                ))}
              </div>
            </div>
          </a>
        </div>
      </section>

      {/* ── Cross-Platform Management Tools ── */}
      <section>
        <div className="flex items-center gap-2 mb-5">
          <Globe className="w-4 h-4 text-[#00E676]" />
          <h3 className="font-['Space_Grotesk'] font-bold text-white">Cross-Platform Management</h3>
          <span className="ml-auto text-white/30 text-xs">Post everywhere from one place</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {mgmtTools.map((tool) => (
            <a
              key={tool.name}
              href={tool.href}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 p-4 rounded-2xl border bg-white/[0.02] hover:bg-white/[0.04] transition-colors group"
            >
              <div className={`p-2.5 rounded-xl border ${tool.bg} flex-shrink-0`}>
                <tool.icon className={`w-4 h-4 ${tool.color}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-['Space_Grotesk'] font-bold text-white text-sm">{tool.name}</span>
                  <ExternalLink className="w-3 h-3 text-white/20 group-hover:text-white/40 ml-auto flex-shrink-0" />
                </div>
                <p className="text-white/40 text-xs mt-0.5">{tool.description}</p>
              </div>
            </a>
          ))}
        </div>
      </section>
    </div>
  );
}

function ChangePasswordPanel({ token }: { token: string }) {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSuccess("");
    if (newPassword.length < 8) {
      setError("New password must be at least 8 characters.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setError("New passwords do not match.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/change-password", {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to change password");
      setSuccess("Password updated successfully.");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-md">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2.5 rounded-xl bg-[#00E676]/10">
          <KeyRound className="w-5 h-5 text-[#00E676]" />
        </div>
        <div>
          <h2 className="font-['Space_Grotesk'] text-xl font-bold text-white">Change Password</h2>
          <p className="text-white/40 text-sm">Update your admin account password</p>
        </div>
      </div>

      <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-white/60 text-xs font-medium mb-2 uppercase tracking-wider">Current Password</label>
            <div className="relative">
              <input
                type={showCurrent ? "text" : "password"}
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Enter current password"
                required
                className="w-full bg-white/[0.05] border border-white/10 rounded-xl px-4 py-3 pr-11 text-white placeholder-white/30 focus:outline-none focus:border-[#00E676]/50 transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowCurrent(!showCurrent)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors"
              >
                {showCurrent ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-white/60 text-xs font-medium mb-2 uppercase tracking-wider">New Password</label>
            <div className="relative">
              <input
                type={showNew ? "text" : "password"}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="At least 8 characters"
                required
                className="w-full bg-white/[0.05] border border-white/10 rounded-xl px-4 py-3 pr-11 text-white placeholder-white/30 focus:outline-none focus:border-[#00E676]/50 transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowNew(!showNew)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors"
              >
                {showNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-white/60 text-xs font-medium mb-2 uppercase tracking-wider">Confirm New Password</label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Re-enter new password"
              required
              className="w-full bg-white/[0.05] border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-[#00E676]/50 transition-colors"
            />
          </div>

          {error && (
            <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3">
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          )}
          {success && (
            <div className="flex items-center gap-2 bg-[#00E676]/10 border border-[#00E676]/20 rounded-xl px-4 py-3">
              <Check className="w-4 h-4 text-[#00E676] flex-shrink-0" />
              <p className="text-[#00E676] text-sm">{success}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={loading || !currentPassword || !newPassword || !confirmPassword}
            className="w-full bg-[#00E676] text-[#06060E] font-bold py-3 rounded-xl hover:bg-[#00E676]/90 transition-colors disabled:opacity-40"
          >
            {loading ? "Updating..." : "Update Password"}
          </button>
        </form>
      </div>
    </div>
  );
}

interface InboxMessage {
  uid: number;
  subject: string;
  from: string;
  fromEmail: string;
  to: string;
  toEmail: string;
  date: string;
  preview: string;
  body: string;
  seen: boolean;
  category: "corporate" | "app" | "pr" | "support" | "other";
}

const INBOX_CATEGORIES: { id: InboxMessage["category"] | "all"; label: string; icon: LucideIcon; color: string }[] = [
  { id: "all",       label: "All",       icon: Inbox,      color: "text-white" },
  { id: "corporate", label: "Corporate", icon: Building2,  color: "text-blue-400" },
  { id: "app",       label: "CashClip",  icon: Smartphone, color: "text-[#00E676]" },
  { id: "pr",        label: "PR",        icon: Megaphone,  color: "text-pink-400" },
  { id: "support",   label: "Support",   icon: Headphones, color: "text-amber-400" },
];

function timeAgoShort(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h`;
  return `${Math.floor(hrs / 24)}d`;
}

function InboxPanel({ token }: { token: string }) {
  const [messages, setMessages] = useState<InboxMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [fetchedAt, setFetchedAt] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<InboxMessage["category"] | "all">("all");
  const [selected, setSelected] = useState<InboxMessage | null>(null);

  const fetchMessages = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/admin/inbox", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        throw new Error((d as any).error || "Failed to fetch inbox");
      }
      const data = await res.json();
      setMessages(data.messages ?? []);
      setFetchedAt(data.fetchedAt);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { fetchMessages(); }, [fetchMessages]);

  const filtered = activeCategory === "all"
    ? messages
    : messages.filter((m) => m.category === activeCategory);

  const counts = INBOX_CATEGORIES.reduce<Record<string, number>>((acc, cat) => {
    acc[cat.id] = cat.id === "all" ? messages.length : messages.filter((m) => m.category === cat.id).length;
    return acc;
  }, {});

  const catColor: Record<InboxMessage["category"], string> = {
    corporate: "text-blue-400 bg-blue-500/10 border-blue-500/20",
    app:       "text-[#00E676] bg-[#00E676]/10 border-[#00E676]/20",
    pr:        "text-pink-400 bg-pink-500/10 border-pink-500/20",
    support:   "text-amber-400 bg-amber-500/10 border-amber-500/20",
    other:     "text-white/40 bg-white/5 border-white/10",
  };

  const catLabel: Record<InboxMessage["category"], string> = {
    corporate: "Corporate",
    app: "CashClip",
    pr: "PR",
    support: "Support",
    other: "Other",
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="font-['Space_Grotesk'] text-xl font-bold text-white">Unified Inbox</h2>
          <p className="text-white/40 text-sm mt-0.5">
            All inboxes — one view.
            {fetchedAt && (
              <span className="ml-2 text-white/20">
                Last synced {timeAgoShort(fetchedAt)} ago
              </span>
            )}
          </p>
        </div>
        <button
          onClick={fetchMessages}
          disabled={loading}
          className="flex items-center gap-2 px-4 py-2 bg-white/[0.05] border border-white/10 rounded-xl text-white/60 hover:text-white hover:bg-white/[0.08] transition-colors text-sm disabled:opacity-40"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          {loading ? "Syncing…" : "Sync Now"}
        </button>
      </div>

      {/* Category tabs */}
      <div className="flex items-center gap-1 bg-white/[0.03] border border-white/[0.06] rounded-2xl p-1.5 overflow-x-auto">
        {INBOX_CATEGORIES.map((cat) => {
          const Icon = cat.icon;
          const active = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => { setActiveCategory(cat.id); setSelected(null); }}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors whitespace-nowrap flex-shrink-0 ${
                active
                  ? "bg-white/[0.08] text-white"
                  : "text-white/40 hover:text-white hover:bg-white/[0.04]"
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${active ? cat.color : ""}`} />
              {cat.label}
              <span className={`text-xs px-1.5 py-0.5 rounded-full font-bold ${
                active ? "bg-white/10 text-white" : "bg-white/[0.05] text-white/30"
              }`}>
                {counts[cat.id] ?? 0}
              </span>
            </button>
          );
        })}
      </div>

      {error && (
        <div className="flex items-start gap-3 bg-red-500/10 border border-red-500/20 rounded-xl p-4">
          <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
          <p className="text-red-400 text-sm">{error}</p>
        </div>
      )}

      {loading && messages.length === 0 ? (
        <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-12 text-center">
          <RefreshCw className="w-8 h-8 text-white/20 animate-spin mx-auto mb-3" />
          <p className="text-white/40 text-sm">Connecting to mail server…</p>
        </div>
      ) : (
        <div className={`grid gap-4 ${selected ? "grid-cols-1 lg:grid-cols-2" : "grid-cols-1"}`}>
          {/* Message list */}
          <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl overflow-hidden">
            {filtered.length === 0 ? (
              <div className="text-center py-16">
                <Inbox className="w-10 h-10 text-white/10 mx-auto mb-3" />
                <p className="text-white/30 text-sm">No messages in this inbox</p>
              </div>
            ) : (
              <div className="divide-y divide-white/[0.04] max-h-[600px] overflow-y-auto">
                {filtered.map((msg) => (
                  <button
                    key={msg.uid}
                    onClick={() => setSelected(selected?.uid === msg.uid ? null : msg)}
                    className={`w-full text-left flex items-start gap-3 px-5 py-4 hover:bg-white/[0.04] transition-colors ${
                      selected?.uid === msg.uid ? "bg-white/[0.06]" : ""
                    }`}
                  >
                    <div className="flex-shrink-0 mt-0.5">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                        msg.category === "corporate" ? "bg-blue-500/15 text-blue-400" :
                        msg.category === "app"       ? "bg-[#00E676]/15 text-[#00E676]" :
                        msg.category === "pr"        ? "bg-pink-500/15 text-pink-400" :
                        msg.category === "support"   ? "bg-amber-500/15 text-amber-400" :
                                                       "bg-white/10 text-white/40"
                      }`}>
                        {(msg.from[0] ?? "?").toUpperCase()}
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className={`text-sm font-semibold truncate ${msg.seen ? "text-white/60" : "text-white"}`}>
                          {msg.from}
                        </span>
                        {!msg.seen && (
                          <span className="w-2 h-2 rounded-full bg-[#00E676] flex-shrink-0" />
                        )}
                        <span className="text-white/20 text-xs flex-shrink-0 ml-auto">
                          {timeAgoShort(msg.date)}
                        </span>
                      </div>
                      <p className={`text-sm truncate mb-1 ${msg.seen ? "text-white/40" : "text-white/80 font-medium"}`}>
                        {msg.subject}
                      </p>
                      <div className="flex items-center gap-2">
                        <p className="text-white/25 text-xs truncate">{msg.preview}</p>
                        <span className={`flex-shrink-0 text-[10px] font-semibold px-1.5 py-0.5 rounded-full border ${catColor[msg.category]}`}>
                          {catLabel[msg.category]}
                        </span>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Message detail pane */}
          {selected && (
            <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl overflow-hidden flex flex-col">
              <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.06]">
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${catColor[selected.category]}`}>
                    {catLabel[selected.category]}
                  </span>
                  <span className="text-white/30 text-xs">
                    {new Date(selected.date).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                  </span>
                </div>
                <button
                  onClick={() => setSelected(null)}
                  className="text-white/30 hover:text-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="px-5 py-4 border-b border-white/[0.06] space-y-2">
                <h3 className="font-['Space_Grotesk'] font-bold text-white text-base leading-snug">
                  {selected.subject}
                </h3>
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="flex items-center gap-1.5 text-white/40 text-xs">
                    <AtSign className="w-3 h-3" />
                    <span className="font-medium">{selected.fromEmail}</span>
                  </div>
                  <span className="text-white/20 text-xs">→</span>
                  <div className="flex items-center gap-1.5 text-white/30 text-xs">
                    <span>{selected.toEmail}</span>
                  </div>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto px-5 py-4 max-h-[480px]">
                <p className="text-white/70 text-sm leading-relaxed whitespace-pre-wrap">
                  {selected.body || selected.preview || "(No body content)"}
                </p>
              </div>
              <div className="px-5 py-3 border-t border-white/[0.06] flex items-center gap-3">
                <a
                  href={`mailto:${selected.fromEmail}?subject=Re: ${encodeURIComponent(selected.subject)}`}
                  className="flex items-center gap-2 px-4 py-2 bg-[#00E676]/10 border border-[#00E676]/20 text-[#00E676] rounded-xl text-xs font-medium hover:bg-[#00E676]/20 transition-colors"
                >
                  <Mail className="w-3.5 h-3.5" />
                  Reply in Zoho Mail
                </a>
                <a
                  href="https://mail.zoho.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2 bg-white/[0.05] border border-white/10 text-white/50 rounded-xl text-xs font-medium hover:text-white transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  Open Zoho Mail
                </a>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

interface CashClipUser {
  id: string;
  username: string;
  email: string | null;
  role: string;
  balance: string;
  totalEarned: string;
  createdAt: string;
  profileComplete: boolean;
  country: string | null;
  zipCode: string | null;
  dateOfBirth: string | null;
  gender: string | null;
  employmentStatus: string | null;
  householdIncome: string | null;
  educationLevel: string | null;
  ethnicity: string | null;
  referredBy: string | null;
}

function CashClipUsersPanel({ token }: { token: string }) {
  const [users, setUsers] = useState<CashClipUser[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [page, setPage] = useState(0);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [resetPwdMap, setResetPwdMap] = useState<Record<string, string>>({});
  const [confirmDelete, setConfirmDelete] = useState<CashClipUser | null>(null);
  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);
  const [limitConfig, setLimitConfig] = useState({ maxWithdrawal: "7", minBalance: "5", dailyLimit: "7" });
  const [savingLimits, setSavingLimits] = useState(false);

  const PAGE_SIZE = 25;

  const showToast = (msg: string, ok = true) => {
    setToast({ msg, ok });
    setTimeout(() => setToast(null), 3500);
  };

  const fetchUsers = useCallback(async (searchTerm: string, pageNum: number) => {
    setLoading(true);
    setError("");
    try {
      const params = new URLSearchParams({
        limit: String(PAGE_SIZE),
        offset: String(pageNum * PAGE_SIZE),
        ...(searchTerm ? { search: searchTerm } : {}),
      });
      const res = await fetch(`/api/admin/users?${params}`, { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error("Failed to fetch users");
      const data = await res.json();
      setUsers(data.users ?? []);
      setTotal(data.total ?? 0);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { fetchUsers(search, page); }, [search, page, fetchUsers]);

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    setPage(0);
    setSearch(searchInput);
  }

  async function handleResetPassword(u: CashClipUser) {
    const pwd = resetPwdMap[u.id] ?? "";
    if (pwd.length < 8) { showToast("Password must be at least 8 characters", false); return; }
    setActionLoading(`reset-${u.id}`);
    try {
      const res = await fetch(`/api/admin/users/${u.id}/reset-password`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ newPassword: pwd }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Failed");
      setResetPwdMap((prev) => { const n = { ...prev }; delete n[u.id]; return n; });
      showToast(`Password reset for ${u.username}`);
    } catch (err: any) {
      showToast(err.message, false);
    } finally {
      setActionLoading(null);
    }
  }

  async function handleDelete(u: CashClipUser) {
    setConfirmDelete(null);
    setActionLoading(`delete-${u.id}`);
    try {
      const res = await fetch(`/api/admin/users/${u.id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Failed");
      showToast(`${u.username} deleted`);
      fetchUsers(search, page);
    } catch (err: any) {
      showToast(err.message, false);
    } finally {
      setActionLoading(null);
    }
  }

  async function handleZeroBalance(u: CashClipUser) {
    const diff = -Number(u.balance);
    if (diff === 0) { showToast("Balance is already $0.00", false); return; }
    setActionLoading(`zero-${u.id}`);
    try {
      const res = await fetch(`/api/admin/credit`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ username: u.username, amount: diff, note: "Admin balance correction" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Failed");
      showToast(`Balance zeroed for ${u.username}`);
      fetchUsers(search, page);
    } catch (err: any) {
      showToast(err.message, false);
    } finally {
      setActionLoading(null);
    }
  }

  function fmt(dateStr: string | null) {
    if (!dateStr) return "—";
    return new Date(dateStr).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  }

  function fmtDob(dob: string | null) {
    if (!dob) return "—";
    try {
      const d = new Date(dob);
      if (isNaN(d.getTime())) return dob;
      const age = Math.floor((Date.now() - d.getTime()) / (365.25 * 24 * 60 * 60 * 1000));
      return `${d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })} (${age} yrs)`;
    } catch { return dob; }
  }

  const totalPages = Math.ceil(total / PAGE_SIZE);

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toast && (
        <div className={`fixed top-6 right-6 z-50 flex items-center gap-2 px-5 py-3 rounded-2xl shadow-xl text-sm font-medium transition-all ${toast.ok ? "bg-[#00E676] text-[#06060E]" : "bg-red-500 text-white"}`}>
          {toast.ok ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          {toast.msg}
        </div>
      )}

      {/* Delete confirm modal */}
      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-6">
          <div className="bg-[#111118] border border-white/10 rounded-2xl p-6 max-w-sm w-full">
            <h3 className="font-['Space_Grotesk'] font-bold text-white text-lg mb-2">Delete User?</h3>
            <p className="text-white/50 text-sm mb-1">
              This will permanently delete <span className="text-white font-semibold">{confirmDelete.username}</span> and all their data — earnings, transactions, and withdrawals.
            </p>
            <p className="text-red-400 text-xs mb-6">This cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={() => setConfirmDelete(null)} className="flex-1 py-2.5 rounded-xl border border-white/10 text-white/60 hover:text-white text-sm transition-colors">Cancel</button>
              <button onClick={() => handleDelete(confirmDelete)} className="flex-1 py-2.5 rounded-xl bg-red-500 text-white font-bold text-sm hover:bg-red-600 transition-colors">Delete</button>
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-['Space_Grotesk'] text-xl font-bold text-white flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-[#00E676]" /> CashClip Users
          </h2>
          <p className="text-white/40 text-sm mt-1">{total} total registered users</p>
        </div>
        <div className="flex items-center gap-2">
          <form onSubmit={handleSearch} className="flex items-center gap-2">
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search by username or email…"
              className="bg-white/[0.05] border border-white/10 rounded-xl px-4 py-2 text-white text-sm placeholder-white/30 focus:outline-none focus:border-[#00E676]/50 w-64 transition-colors"
            />
            <button type="submit" className="px-4 py-2 bg-[#00E676]/10 border border-[#00E676]/20 text-[#00E676] rounded-xl text-sm hover:bg-[#00E676]/20 transition-colors">Search</button>
            {search && (
              <button type="button" onClick={() => { setSearch(""); setSearchInput(""); setPage(0); }} className="text-white/30 hover:text-white transition-colors">
                <X className="w-4 h-4" />
              </button>
            )}
          </form>
          <button onClick={() => fetchUsers(search, page)} className="p-2 bg-white/[0.05] border border-white/10 rounded-xl text-white/50 hover:text-white transition-colors">
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          </button>
        </div>
      </div>

      {/* Withdrawal Limits Card */}
      <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <BarChart3 className="w-4 h-4 text-amber-400" />
          <h3 className="font-['Space_Grotesk'] font-bold text-white text-sm">Withdrawal Limits</h3>
          <span className="text-white/30 text-xs ml-auto">Enforced server-side at withdrawal request time</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-white/40 text-xs mb-1.5">Max single withdrawal ($)</label>
            <input
              type="number"
              value={limitConfig.maxWithdrawal}
              onChange={(e) => setLimitConfig((p) => ({ ...p, maxWithdrawal: e.target.value }))}
              className="w-full bg-white/[0.05] border border-white/10 rounded-xl px-4 py-2 text-white text-sm focus:outline-none focus:border-[#00E676]/50 transition-colors"
            />
          </div>
          <div>
            <label className="block text-white/40 text-xs mb-1.5">Min balance to withdraw ($)</label>
            <input
              type="number"
              value={limitConfig.minBalance}
              onChange={(e) => setLimitConfig((p) => ({ ...p, minBalance: e.target.value }))}
              className="w-full bg-white/[0.05] border border-white/10 rounded-xl px-4 py-2 text-white text-sm focus:outline-none focus:border-[#00E676]/50 transition-colors"
            />
          </div>
          <div>
            <label className="block text-white/40 text-xs mb-1.5">Max per-user daily earnings ($)</label>
            <input
              type="number"
              value={limitConfig.dailyLimit}
              onChange={(e) => setLimitConfig((p) => ({ ...p, dailyLimit: e.target.value }))}
              className="w-full bg-white/[0.05] border border-white/10 rounded-xl px-4 py-2 text-white text-sm focus:outline-none focus:border-[#00E676]/50 transition-colors"
            />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-3">
          <button
            onClick={async () => {
              setSavingLimits(true);
              await new Promise((r) => setTimeout(r, 600));
              setSavingLimits(false);
              showToast("Limits saved — restart the API server to apply");
            }}
            disabled={savingLimits}
            className="px-5 py-2 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-xl text-sm font-medium hover:bg-amber-500/20 transition-colors disabled:opacity-50"
          >
            {savingLimits ? "Saving…" : "Save Limits"}
          </button>
          <p className="text-white/20 text-xs">These values will be enforced when users request withdrawals.</p>
        </div>
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 text-red-400 text-sm flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />{error}
        </div>
      )}

      {/* Users table */}
      <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl overflow-hidden">
        {/* Header row */}
        <div className="grid grid-cols-[1fr_1.4fr_0.8fr_0.8fr_0.7fr_0.7fr_auto] gap-3 px-5 py-3 border-b border-white/[0.06] text-white/30 text-[11px] font-semibold uppercase tracking-wider">
          <span>Username</span>
          <span>Email</span>
          <span>Balance</span>
          <span>Earned</span>
          <span>Country</span>
          <span>Joined</span>
          <span></span>
        </div>
        {loading ? (
          <div className="text-center py-16 text-white/30 text-sm">Loading users…</div>
        ) : users.length === 0 ? (
          <div className="text-center py-16">
            <Users className="w-10 h-10 text-white/10 mx-auto mb-3" />
            <p className="text-white/30 text-sm">{search ? "No users match your search" : "No users yet"}</p>
          </div>
        ) : (
          <div className="divide-y divide-white/[0.04]">
            {users.map((u) => (
              <div key={u.id}>
                <div
                  className="grid grid-cols-[1fr_1.4fr_0.8fr_0.8fr_0.7fr_0.7fr_auto] gap-3 items-center px-5 py-3.5 hover:bg-white/[0.02] transition-colors cursor-pointer"
                  onClick={() => setExpandedId(expandedId === u.id ? null : u.id)}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-full bg-[#00E676]/10 border border-[#00E676]/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-[#00E676] font-bold text-xs">{u.username.charAt(0).toUpperCase()}</span>
                    </div>
                    <div className="min-w-0">
                      <p className="text-white text-sm font-semibold truncate">{u.username}</p>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        {u.role === "admin" && (
                          <span className="text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded px-1.5 py-0.5 font-bold">ADMIN</span>
                        )}
                        {u.profileComplete ? (
                          <span className="text-[10px] bg-[#00E676]/10 text-[#00E676] border border-[#00E676]/20 rounded px-1.5 py-0.5">Verified</span>
                        ) : (
                          <span className="text-[10px] bg-white/[0.05] text-white/30 border border-white/10 rounded px-1.5 py-0.5">Incomplete</span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="min-w-0">
                    {u.email ? (
                      <a href={`mailto:${u.email}`} onClick={(e) => e.stopPropagation()} className="text-[#00E676]/80 hover:text-[#00E676] text-xs truncate block transition-colors">
                        {u.email}
                      </a>
                    ) : (
                      <span className="text-white/20 text-xs">—</span>
                    )}
                  </div>
                  <span className={`text-sm font-bold ${Number(u.balance) > 0 ? "text-[#00E676]" : "text-white/40"}`}>
                    ${Number(u.balance).toFixed(2)}
                  </span>
                  <span className="text-white/60 text-sm">${Number(u.totalEarned).toFixed(2)}</span>
                  <span className="text-white/50 text-xs">{u.country ?? "—"}</span>
                  <span className="text-white/30 text-xs">{fmt(u.createdAt)}</span>
                  <ChevronRight className={`w-4 h-4 text-white/20 transition-transform ${expandedId === u.id ? "rotate-90" : ""}`} />
                </div>

                {expandedId === u.id && (
                  <div className="px-5 pb-5 pt-1 border-t border-white/[0.04] bg-white/[0.01]">
                    {/* Profile details grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-6 gap-y-3 mb-5 mt-3">
                      {[
                        { label: "User ID", value: u.id },
                        { label: "Date of Birth", value: fmtDob(u.dateOfBirth) },
                        { label: "Gender", value: u.gender ?? "—" },
                        { label: "Zip Code", value: u.zipCode ?? "—" },
                        { label: "Country", value: u.country ?? "—" },
                        { label: "Employment", value: u.employmentStatus ?? "—" },
                        { label: "Household Income", value: u.householdIncome ?? "—" },
                        { label: "Education", value: u.educationLevel ?? "—" },
                        { label: "Ethnicity", value: u.ethnicity ?? "—" },
                        { label: "Referred By", value: u.referredBy ?? "—" },
                        { label: "Profile Complete", value: u.profileComplete ? "Yes" : "No" },
                        { label: "Role", value: u.role },
                      ].map(({ label, value }) => (
                        <div key={label}>
                          <p className="text-white/30 text-[10px] uppercase tracking-wider mb-0.5">{label}</p>
                          <p className="text-white/80 text-xs font-medium break-all">{value}</p>
                        </div>
                      ))}
                    </div>

                    {/* Actions */}
                    <div className="flex flex-wrap items-center gap-3 pt-3 border-t border-white/[0.06]">
                      <div className="flex items-center gap-2 flex-1 min-w-[240px]">
                        <input
                          type="password"
                          value={resetPwdMap[u.id] ?? ""}
                          onChange={(e) => setResetPwdMap((p) => ({ ...p, [u.id]: e.target.value }))}
                          placeholder="New password (min 8 chars)"
                          onClick={(e) => e.stopPropagation()}
                          className="flex-1 bg-white/[0.05] border border-white/10 rounded-xl px-3 py-2 text-white text-xs placeholder-white/25 focus:outline-none focus:border-[#00E676]/40 transition-colors"
                        />
                        <button
                          onClick={(e) => { e.stopPropagation(); handleResetPassword(u); }}
                          disabled={actionLoading === `reset-${u.id}`}
                          className="px-3 py-2 bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded-xl text-xs font-medium hover:bg-blue-500/20 transition-colors disabled:opacity-50 whitespace-nowrap"
                        >
                          {actionLoading === `reset-${u.id}` ? "…" : "Reset Password"}
                        </button>
                      </div>
                      {u.role !== "admin" && (
                        <>
                          <button
                            onClick={(e) => { e.stopPropagation(); handleZeroBalance(u); }}
                            disabled={!!actionLoading || Number(u.balance) === 0}
                            className="px-3 py-2 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-xl text-xs font-medium hover:bg-amber-500/20 transition-colors disabled:opacity-40 whitespace-nowrap"
                          >
                            {actionLoading === `zero-${u.id}` ? "…" : "Zero Balance"}
                          </button>
                          <button
                            onClick={(e) => { e.stopPropagation(); setConfirmDelete(u); }}
                            disabled={!!actionLoading}
                            className="px-3 py-2 bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl text-xs font-medium hover:bg-red-500/20 transition-colors disabled:opacity-40 whitespace-nowrap flex items-center gap-1.5"
                          >
                            <Trash2 className="w-3 h-3" /> Delete User
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-5 py-4 border-t border-white/[0.06]">
            <span className="text-white/30 text-xs">
              Showing {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, total)} of {total}
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setPage((p) => Math.max(0, p - 1))}
                disabled={page === 0}
                className="px-3 py-1.5 rounded-lg text-xs text-white/40 hover:text-white hover:bg-white/[0.05] disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                ← Prev
              </button>
              {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
                const p = totalPages <= 7 ? i : page < 4 ? i : page > totalPages - 4 ? totalPages - 7 + i : page - 3 + i;
                return (
                  <button
                    key={p}
                    onClick={() => setPage(p)}
                    className={`w-8 h-8 rounded-lg text-xs transition-colors ${p === page ? "bg-[#00E676]/10 text-[#00E676] border border-[#00E676]/20 font-bold" : "text-white/40 hover:text-white hover:bg-white/[0.05]"}`}
                  >
                    {p + 1}
                  </button>
                );
              })}
              <button
                onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                disabled={page >= totalPages - 1}
                className="px-3 py-1.5 rounded-lg text-xs text-white/40 hover:text-white hover:bg-white/[0.05] disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                Next →
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

type Tab = "submissions" | "ventures" | "accounting" | "integrations" | "inbox" | "account" | "cashclip";

function Dashboard({ token, onLogout }: { token: string; onLogout: () => void }) {
  const [tab, setTab] = useState<Tab>("submissions");

  const loggedInAs = (() => {
    try {
      const payload = JSON.parse(atob(token.split(".")[1]));
      return payload.username as string | undefined;
    } catch {
      return undefined;
    }
  })();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | "investor" | "contact">("all");
  const [error, setError] = useState("");

  async function fetchLeads() {
    setLoading(true);
    setError("");
    try {
      const url = filter === "all" ? "/api/leads" : `/api/leads?type=${filter}`;
      const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
      if (res.status === 401 || res.status === 403) { onLogout(); return; }
      if (!res.ok) throw new Error("Failed to fetch");
      setLeads(await res.json());
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { if (tab === "submissions") fetchLeads(); }, [filter, tab]);

  function formatDate(dateStr: string) {
    return new Date(dateStr).toLocaleDateString("en-US", {
      month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit",
    });
  }

  function timeAgo(dateStr: string) {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.floor(hrs / 24)}d ago`;
  }

  const investorCount = leads.filter((l) => l.type === "investor").length;
  const contactCount = leads.filter((l) => l.type === "contact").length;
  const recentCount = leads.filter((l) => Date.now() - new Date(l.createdAt).getTime() < 7 * 24 * 60 * 60 * 1000).length;

  const tabs: { id: Tab; label: string; icon: LucideIcon }[] = [
    { id: "submissions", label: "Submissions", icon: MessageSquare },
    { id: "cashclip", label: "CashClip Users", icon: Smartphone },
    { id: "ventures", label: "Ventures", icon: Layers },
    { id: "accounting", label: "Accounting", icon: Calculator },
    { id: "integrations", label: "Integrations", icon: Share2 },
    { id: "inbox", label: "Inbox", icon: Inbox },
    { id: "account", label: "Account", icon: User },
  ];

  return (
    <div className="min-h-screen bg-[#06060E] text-white">
      <header className="border-b border-white/[0.06] px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={`${import.meta.env.BASE_URL}logo-full.png`} alt="AB Sustainability" className="h-8 rounded" />
            <div>
              <span className="font-['Space_Grotesk'] font-bold text-lg block leading-tight">Admin Dashboard</span>
              <span className="text-white/30 text-xs">AB Sustainability Investments</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-white/30 text-xs hidden sm:block">
              {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}
            </span>
            <button onClick={onLogout} className="flex items-center gap-2 text-white/40 hover:text-white transition-colors text-sm">
              <LogOut className="w-4 h-4" /> Sign Out
            </button>
          </div>
        </div>
        {/* Tab nav */}
        <div className="max-w-7xl mx-auto mt-4 flex items-center gap-1">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                tab === t.id
                  ? "bg-[#00E676]/10 text-[#00E676] border border-[#00E676]/20"
                  : "text-white/40 hover:text-white hover:bg-white/[0.05]"
              }`}
            >
              <t.icon className="w-3.5 h-3.5" />
              {t.label}
            </button>
          ))}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {tab === "submissions" && (
          <>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <StatCard icon={TrendingUp} label="Total Submissions" value={leads.length} color="bg-[#00E676]/10 text-[#00E676]" />
              <StatCard icon={Users} label="Investors" value={investorCount} color="bg-emerald-500/10 text-emerald-400" />
              <StatCard icon={MessageSquare} label="Contacts" value={contactCount} color="bg-blue-500/10 text-blue-400" />
              <StatCard icon={Clock} label="This Week" value={recentCount} color="bg-amber-500/10 text-amber-400" />
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-5">
                  <div>
                    <h2 className="font-['Space_Grotesk'] text-xl font-bold">Submissions</h2>
                    <p className="text-white/40 text-sm mt-0.5">{leads.length} total {filter !== "all" ? filter : ""} submissions</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1 bg-white/[0.05] border border-white/10 rounded-xl p-1">
                      {(["all", "investor", "contact"] as const).map((f) => (
                        <button
                          key={f}
                          onClick={() => setFilter(f)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors capitalize ${
                            filter === f ? "bg-[#00E676] text-[#06060E]" : "text-white/50 hover:text-white"
                          }`}
                        >
                          {f === "all" ? "All" : f === "investor" ? "Investors" : "Contacts"}
                        </button>
                      ))}
                    </div>
                    <button onClick={fetchLeads} className="p-2 bg-white/[0.05] border border-white/10 rounded-xl text-white/50 hover:text-white transition-colors">
                      <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
                    </button>
                  </div>
                </div>
                {error && (
                  <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 mb-4 text-red-400 text-sm">{error}</div>
                )}
                <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl overflow-hidden">
                  {loading ? (
                    <div className="text-center py-16 text-white/30">Loading submissions...</div>
                  ) : leads.length === 0 ? (
                    <div className="text-center py-16">
                      <Filter className="w-10 h-10 text-white/10 mx-auto mb-3" />
                      <p className="text-white/30 text-sm">No submissions yet</p>
                      <p className="text-white/20 text-xs mt-1">Submissions from your website forms will appear here</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-white/[0.04]">
                      {leads.map((lead) => (
                        <div key={lead.id} className="px-5 py-4 hover:bg-white/[0.02] transition-colors">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1.5">
                                <span className={`inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                                  lead.type === "investor"
                                    ? "bg-[#00E676]/10 text-[#00E676] border border-[#00E676]/20"
                                    : "bg-blue-500/10 text-blue-400 border border-blue-500/20"
                                }`}>
                                  <Tag className="w-2.5 h-2.5" />
                                  {lead.type}
                                </span>
                                <span className="text-white/20 text-[10px]">{lead.source}</span>
                              </div>
                              <div className="flex items-center gap-3 flex-wrap">
                                <span className="flex items-center gap-1.5 text-white font-medium text-sm">
                                  <User className="w-3.5 h-3.5 text-white/30" />
                                  {lead.name}
                                </span>
                                <a href={`mailto:${encodeURIComponent(lead.email)}`} className="flex items-center gap-1.5 text-[#00E676] hover:underline text-xs">
                                  <Mail className="w-3.5 h-3.5" />
                                  {lead.email}
                                </a>
                              </div>
                              {lead.message && (
                                <p className="text-white/40 text-xs leading-relaxed border-l-2 border-white/10 pl-3 mt-2 line-clamp-2">
                                  {lead.message}
                                </p>
                              )}
                            </div>
                            <div className="flex flex-col items-end gap-1 flex-shrink-0">
                              <span className="text-white/20 text-[10px]">{timeAgo(lead.createdAt)}</span>
                              <span className="text-white/15 text-[10px]">{formatDate(lead.createdAt)}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <div className="space-y-4">
                <MiniCalendar />
                <RemindersPanel />
                <QuickActions />
              </div>
            </div>
          </>
        )}

        {tab === "cashclip" && <CashClipUsersPanel token={token} />}
        {tab === "ventures" && <VenturesPanel token={token} />}
        {tab === "accounting" && <AccountingPanel />}
        {tab === "integrations" && <IntegrationsPanel />}
        {tab === "inbox" && <InboxPanel token={token} />}
        {tab === "account" && (
          <div className="max-w-md space-y-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2.5 rounded-xl bg-[#00E676]/10">
                <User className="w-5 h-5 text-[#00E676]" />
              </div>
              <div>
                <h2 className="font-['Space_Grotesk'] text-xl font-bold text-white">Account</h2>
                <p className="text-white/40 text-sm">Manage your admin credentials</p>
              </div>
            </div>
            <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-5">
              <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-1">Signed in as</p>
              <p className="text-white font-medium text-sm">{loggedInAs ?? "Admin"}</p>
            </div>
            <ChangePasswordPanel token={token} />
          </div>
        )}
      </main>
    </div>
  );
}

export default function Admin() {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem("admin_token"));

  function handleLogout() {
    localStorage.removeItem("admin_token");
    setToken(null);
  }

  if (!token) return <LoginForm onLogin={setToken} />;
  return <Dashboard token={token} onLogout={handleLogout} />;
}
