import type { Express, Request, Response, NextFunction } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import { storage } from "./storage";
import { logger } from "./lib/logger";
import { sendEmailVerification, sendPasswordResetOTP } from "./lib/email";
import { recordLoginAttempt, checkLoginAttempts, clearLoginAttempts, pruneExpiredLoginAttempts } from "./lib/dbRateLimit";
import { getClientIp } from "./lib/clientIp";
import { validateRegistrationEmail } from "./lib/emailValidation";
import type { InsertUser } from "@workspace/db";
import { db, passwordResetTokens, users } from "@workspace/db";
import { eq as drizzleEq, and as drizzleAnd, isNull as drizzleIsNull, gte as drizzleGte, lt as drizzleLt, sql as drizzleSql } from "drizzle-orm";
import { generateTotpSecret, verifyTotp } from "./lib/totp";

// ── TOTP verify rate-limit constants ─────────────────────────────────────────
// Both counters are DB-backed so they are shared across all autoscaled replicas.
const MAX_TOTP_ATTEMPTS = 5;          // per pending-token (5-minute window)
const MAX_TOTP_ATTEMPTS_PER_IP = 20;  // per IP (15-minute window)
const TOTP_TOKEN_WINDOW_MS = 5 * 60 * 1000;   // matches pending-token lifetime
const TOTP_IP_WINDOW_MS   = 15 * 60 * 1000;

function getTotpTokenKey(totpSessionToken: string): string {
  return "totp:token:" + crypto.createHash("sha256").update(totpSessionToken).digest("hex");
}

// Resolved lazily so the server can start and pass the health check even when
// JWT_ACCESS_SECRET hasn't been linked to the production environment yet.
// JWT_ACCESS_SECRET is the primary signing key for access tokens (HS256 fallback).
// JWT_SECRET is accepted as a legacy alias.
function getJwtSecret(): string {
  const s = process.env.JWT_ACCESS_SECRET ?? process.env.JWT_SECRET;
  if (!s) throw new Error("JWT_ACCESS_SECRET environment variable is required");
  return s;
}

// ── HS256 rotation fallback ───────────────────────────────────────────────────
// Only used to verify tokens signed by the old HS256 secret during the 2h
// transition window after a keyswitch.
function getPrevJwtSecret(): string | null {
  const s = process.env.JWT_ACCESS_SECRET_PREV;
  if (!s) return null;
  return s;
}

const TOKEN_EXPIRY = "2h";

// ── JWT_REFRESH_SECRET — refresh token layer ──────────────────────────────────
// Signs long-lived refresh tokens (30d) stored in the rid httpOnly cookie.
// When the short-lived JWT (2h) expires, POST /api/auth/refresh
// exchanges a valid rid cookie for a fresh JWT + sid cookie without re-login.
const REFRESH_SECRET = process.env.JWT_REFRESH_SECRET;
const REFRESH_TOKEN_EXPIRY = "30d";
const REFRESH_COOKIE_MAX_AGE_MS = 30 * 24 * 60 * 60 * 1000;
const RID_COOKIE = "rid";

function generateRefreshToken(userId: string, tokenVersion: number): string | null {
  if (!REFRESH_SECRET) return null;
  return jwt.sign({ userId, tokenVersion, type: "refresh" }, REFRESH_SECRET, {
    expiresIn: REFRESH_TOKEN_EXPIRY,
  });
}

function verifyRefreshToken(token: string): { userId: string; tokenVersion: number } | null {
  if (!REFRESH_SECRET) return null;
  try {
    const decoded = jwt.verify(token, REFRESH_SECRET);
    if (
      typeof decoded === "object" && decoded !== null &&
      "userId" in decoded && "tokenVersion" in decoded &&
      (decoded as Record<string, unknown>).type === "refresh"
    ) {
      return decoded as { userId: string; tokenVersion: number };
    }
    return null;
  } catch {
    return null;
  }
}

export const RESERVED_ADMIN_USERNAMES: ReadonlySet<string> = new Set([
  "support@absustaininvest.com",
  "support@cash-clip.app",
]);

export interface AuthRequest extends Request {
  userId?: string;
  userRole?: string;
}

const RATE_LIMIT_WINDOW_MS = 15 * 60 * 1000;
const MAX_LOGIN_ATTEMPTS_PER_IP = 10;
const MAX_REGISTER_ATTEMPTS_PER_IP = 5;
const LOCKOUT_DURATION_MS = 15 * 60 * 1000;

// Periodically prune expired rows from the shared login_attempts table.
setInterval(() => { pruneExpiredLoginAttempts(); }, 5 * 60 * 1000);

function generateToken(userId: string, role: string, tokenVersion: number): string {
  return jwt.sign({ userId, role, tokenVersion }, getJwtSecret(), { expiresIn: TOKEN_EXPIRY });
}

function verifyToken(token: string): { userId: string; role: string; tokenVersion: number } | null {
  const secrets: string[] = [];
  try { secrets.push(getJwtSecret()); } catch { /* secret not configured */ }
  const prev = getPrevJwtSecret();
  if (prev) secrets.push(prev);

  for (const secret of secrets) {
    try {
      const decoded = jwt.verify(token, secret);
      if (
        typeof decoded === "object" && decoded !== null &&
        "userId" in decoded && "role" in decoded && "tokenVersion" in decoded
      ) {
        return decoded as { userId: string; role: string; tokenVersion: number };
      }
    } catch { /* try next */ }
  }
  return null;
}

const SID_COOKIE = "sid";
const COOKIE_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;

const isProd = process.env.NODE_ENV === "production";

export function setSessionCookie(res: Response, token: string): void {
  if (!process.env.ADMIN_TOKEN) return;
  res.cookie(SID_COOKIE, token, {
    signed: true, httpOnly: true, secure: isProd, sameSite: "strict",
    maxAge: COOKIE_MAX_AGE_MS,
  });
}

export function clearSessionCookie(res: Response): void {
  res.clearCookie(SID_COOKIE, { httpOnly: true, secure: isProd, sameSite: "strict" });
}

export function setRefreshCookie(res: Response, userId: string, tokenVersion: number): void {
  const refreshToken = generateRefreshToken(userId, tokenVersion);
  if (!refreshToken) return;
  res.cookie(RID_COOKIE, refreshToken, {
    httpOnly: true, secure: isProd, sameSite: "strict",
    maxAge: REFRESH_COOKIE_MAX_AGE_MS,
  });
}

export function clearRefreshCookie(res: Response): void {
  res.clearCookie(RID_COOKIE, { httpOnly: true, secure: isProd, sameSite: "strict" });
}

export async function authMiddleware(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  const authHeader = req.headers.authorization;
  // Accept Bearer header first, then fall back to signed sid cookie (ADMIN_TOKEN layer).
  let token: string | undefined;
  if (authHeader?.startsWith("Bearer ")) {
    token = authHeader.split(" ")[1];
  } else if (req.signedCookies?.[SID_COOKIE]) {
    token = req.signedCookies[SID_COOKIE] as string;
  }
  if (!token) {
    res.status(401).json({ error: "No token provided" });
    return;
  }
  const payload = verifyToken(token);
  if (!payload) {
    res.status(401).json({ error: "Invalid or expired token" });
    return;
  }
  const user = await storage.getUser(payload.userId);
  if (!user) {
    res.status(401).json({ error: "Invalid or expired token" });
    return;
  }
  if (user.tokenVersion !== payload.tokenVersion) {
    res.status(401).json({ error: "Invalid or expired token" });
    return;
  }
  req.userId = user.id;
  req.userRole = user.role;
  next();
}

export async function adminMiddleware(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  // A valid admin Bearer JWT is always sufficient — this covers the web portal.
  // The ADMIN_TOKEN console-token path is for internal/programmatic access only.
  const authHeader = req.headers.authorization;
  if (authHeader?.startsWith("Bearer ")) {
    const token = authHeader.split(" ")[1];
    const payload = verifyToken(token);
    if (payload) {
      const user = await storage.getUser(payload.userId);
      if (user && user.tokenVersion === payload.tokenVersion && user.role === "admin") {
        req.userId = user.id;
        req.userRole = user.role;
        next();
        return;
      }
    }
  }

  // Fallback: console-token path (internal tooling / ADMIN_TOKEN secret).
  const consoleToken = process.env.ADMIN_TOKEN;
  if (consoleToken) {
    const provided = req.headers["x-console-token"];
    if (typeof provided !== "string" || !crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(consoleToken))) {
      res.status(401).json({ error: "No token provided" });
      return;
    }
  }
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    res.status(401).json({ error: "No token provided" });
    return;
  }
  const token = authHeader.split(" ")[1];
  const payload = verifyToken(token);
  if (!payload) {
    res.status(401).json({ error: "Invalid or expired token" });
    return;
  }
  const user = await storage.getUser(payload.userId);
  if (!user) {
    res.status(401).json({ error: "User not found" });
    return;
  }
  if (user.tokenVersion !== payload.tokenVersion) {
    res.status(401).json({ error: "Invalid or expired token" });
    return;
  }
  if (user.role !== "admin") {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  req.userId = user.id;
  req.userRole = user.role;
  next();
}

export function registerAuthRoutes(app: Express) {
  app.post("/api/auth/register", async (req: Request, res: Response): Promise<void> => {
    try {
      const ip = getClientIp(req);
      const { allowed: ipRegAllowed } = await recordLoginAttempt(`reg:${ip}`, MAX_REGISTER_ATTEMPTS_PER_IP, RATE_LIMIT_WINDOW_MS);
      if (!ipRegAllowed) {
        res.status(429).json({ error: "Too many attempts. Please try again later." });
        return;
      }

      const { username, password, email, referralCode, agreedToTerms } = req.body;
      if (!username || !password) {
        res.status(400).json({ error: "Username and password are required" });
        return;
      }
      if (typeof username !== "string" || username.trim().length < 3) {
        res.status(400).json({ error: "Username must be at least 3 characters" });
        return;
      }
      if (username.trim().length > 30) {
        res.status(400).json({ error: "Username must be 30 characters or fewer" });
        return;
      }
      if (!/^[a-zA-Z0-9_-]+$/.test(username.trim())) {
        res.status(400).json({ error: "Username may only contain letters, numbers, underscores, and hyphens" });
        return;
      }
      if (typeof password !== "string" || password.length < 8) {
        res.status(400).json({ error: "Password must be at least 8 characters" });
        return;
      }
      if (password.length > 72) {
        res.status(400).json({ error: "Password must be 72 characters or fewer" });
        return;
      }
      if (!email || typeof email !== "string" || email.trim().length === 0) {
        res.status(400).json({ error: "Email is required" });
        return;
      }
      const emailCheck = validateRegistrationEmail(email);
      if (!emailCheck.valid) {
        res.status(400).json({ error: emailCheck.reason ?? "Invalid email address" });
        return;
      }
      if (!agreedToTerms) {
        res.status(400).json({ error: "You must agree to the Terms of Service and Privacy Policy" });
        return;
      }

      const normalizedUsername = username.toLowerCase().trim();
      const normalizedEmail = email.trim().toLowerCase();

      if (RESERVED_ADMIN_USERNAMES.has(normalizedUsername)) {
        res.status(400).json({ error: "Username is not available" });
        return;
      }

      const [existingByUsername, existingByEmail] = await Promise.all([
        storage.getUserByUsername(normalizedUsername),
        storage.getUserByEmail(normalizedEmail),
      ]);

      if (existingByEmail) {
        // Return the same generic message to avoid confirming whether an email is registered
        res.status(200).json({ message: "Registration processed. Please check your email to verify your account." });
        return;
      }

      const hashedPassword = await bcrypt.hash(password, 10);

      if (!existingByUsername) {
        const newUser: InsertUser & { role?: string } = {
          username: normalizedUsername,
          password: hashedPassword,
          email: email.trim().toLowerCase(),
          referredBy: referralCode && typeof referralCode === "string" && referralCode.trim().length > 0 ? referralCode.trim().toLowerCase() : undefined,
        };
        const created = await storage.createUser(newUser);
        // Send verification email (best-effort — never blocks registration)
        const verifyToken = crypto.randomBytes(32).toString("hex");
        const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
        await storage.setEmailVerificationToken(created.id, verifyToken, expiresAt);
        const domain = process.env["EXPO_PUBLIC_DOMAIN"] ?? "cash-clip.app";
        const verifyUrl = `https://${domain}/api/auth/verify-email?token=${verifyToken}`;
        sendEmailVerification({ to: email.trim().toLowerCase(), username: normalizedUsername, verifyUrl });
      }

      res.status(200).json({
        message: "Registration processed. Please check your email to verify your account.",
      });
    } catch (err: unknown) {
      logger.error({ err }, "Register error");
      res.status(500).json({ error: "Registration failed" });
    }
  });

  app.post("/api/auth/resend-verification", async (req: Request, res: Response): Promise<void> => {
    try {
      const { username } = req.body;
      if (!username || typeof username !== "string") {
        res.status(400).json({ error: "Username is required" });
        return;
      }
      const user = await storage.getUserByUsername(username.toLowerCase().trim());
      if (!user || user.emailVerified) {
        res.status(200).json({ message: "If the account exists and is unverified, a new email has been sent." });
        return;
      }
      const verifyToken = crypto.randomBytes(32).toString("hex");
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
      await storage.setEmailVerificationToken(user.id, verifyToken, expiresAt);
      const domain = process.env["EXPO_PUBLIC_DOMAIN"] ?? "cash-clip.app";
      const verifyUrl = `https://${domain}/api/auth/verify-email?token=${verifyToken}`;
      if (!user.email) {
        res.status(200).json({ message: "If the account exists and is unverified, a new email has been sent." });
        return;
      }
      sendEmailVerification({ to: user.email, username: user.username, verifyUrl });
      res.status(200).json({ message: "If the account exists and is unverified, a new email has been sent." });
    } catch (err) {
      logger.error({ err }, "resend-verification error");
      res.status(500).json({ error: "Failed to resend verification email" });
    }
  });

  app.get("/api/auth/verify-email", async (req: Request, res: Response): Promise<void> => {
    const { token } = req.query;
    const fail = (msg: string) => {
      res.status(400).send(`<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>CashClip</title><style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#0A0A0F;color:#fff;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}.card{background:#141420;border-radius:20px;padding:40px 32px;max-width:400px;width:100%;text-align:center}.icon{font-size:48px;margin-bottom:16px}.title{font-size:22px;font-weight:700;margin-bottom:8px}.msg{font-size:15px;color:#888;line-height:1.5;margin-bottom:28px}.btn{display:inline-block;background:#B0FF4C;color:#0A0A0F;font-weight:700;font-size:16px;padding:14px 32px;border-radius:12px;text-decoration:none}</style></head><body><div class="card"><div class="icon">❌</div><div class="title">Verification Failed</div><div class="msg">${msg}</div><a class="btn" href="cashclip://">Open CashClip</a></div></body></html>`);
    };
    if (!token || typeof token !== "string") { fail("Invalid or missing verification link."); return; }
    try {
      const user = await storage.getUserByVerificationToken(token);
      if (!user) { fail("This verification link is invalid or has already been used."); return; }
      if (user.emailVerificationExpiresAt && new Date() > new Date(user.emailVerificationExpiresAt)) {
        fail("This verification link has expired. Please register again or contact support."); return;
      }
      await storage.markEmailVerified(user.id);
      res.send(`<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>CashClip — Email Verified</title><style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#0A0A0F;color:#fff;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}.card{background:#141420;border-radius:20px;padding:40px 32px;max-width:400px;width:100%;text-align:center}.icon{font-size:48px;margin-bottom:16px}.title{font-size:22px;font-weight:700;margin-bottom:8px;color:#B0FF4C}.msg{font-size:15px;color:#888;line-height:1.5;margin-bottom:28px}.btn{display:inline-block;background:#B0FF4C;color:#0A0A0F;font-weight:700;font-size:16px;padding:14px 32px;border-radius:12px;text-decoration:none;margin-bottom:12px;display:block}.sub{font-size:13px;color:#555}</style></head><body><div class="card"><div class="icon">✅</div><div class="title">Email Verified!</div><div class="msg">Your CashClip account is now active. Open the app and log in to start earning.</div><a class="btn" href="cashclip://">Open CashClip</a><div class="sub">If the app doesn't open, launch CashClip manually and log in.</div></div></body></html>`);
    } catch (err) {
      logger.error({ err }, "verify-email error");
      fail("Something went wrong. Please try again or contact support.");
    }
  });

  app.post("/api/auth/login", async (req: Request, res: Response): Promise<void> => {
    try {
      const ip = getClientIp(req);
      const { allowed: ipLoginAllowed } = await recordLoginAttempt(`ip:${ip}`, MAX_LOGIN_ATTEMPTS_PER_IP, RATE_LIMIT_WINDOW_MS);
      if (!ipLoginAllowed) {
        res.status(429).json({ error: "Too many attempts. Please try again later." });
        return;
      }

      const { username, password } = req.body;
      if (!username || !password) {
        res.status(400).json({ error: "Username and password are required" });
        return;
      }

      const normalizedUsername = username.toLowerCase().trim();

      // Per-account lockout was removed: keying the lockout counter on username
      // alone made it trivially attacker-triggerable for any known username —
      // five garbage-password requests from one IP were enough to lock an
      // account for 15 minutes. Because admin usernames are publicly seeded
      // constants, the entire admin pool could be kept continuously locked out
      // by a handful of IPs. The per-IP DB-backed counter (above) is the correct
      // brute-force boundary: it is shared across all replicas, cannot be evaded
      // by rotating target usernames, and does not expose a targeted DoS surface.
      const user = await storage.getUserByUsername(normalizedUsername);
      if (!user) {
        await bcrypt.hash("dummy-timing-equalization", 10);
        res.status(401).json({ error: "Invalid credentials" });
        return;
      }

      const valid = await bcrypt.compare(password, user.password);
      if (!valid) {
        res.status(401).json({ error: "Invalid credentials" });
        return;
      }

      // Non-admin accounts must verify their email before receiving a token.
      // Admin accounts bypass this gate so operators are never locked out.
      if (user.role !== "admin" && !user.emailVerified) {
        res.status(403).json({
          error: "Please verify your email address before logging in. Check your inbox for a verification link.",
          code: "EMAIL_NOT_VERIFIED",
        });
        return;
      }

      // If TOTP is enabled, issue a short-lived pending token instead of the
      // full JWT. The client must complete login via POST /api/auth/totp/verify.
      if (user.totpEnabled && user.totpSecret) {
        const totpSessionToken = jwt.sign(
          { userId: user.id, type: "totp-pending", tokenVersion: user.tokenVersion },
          getJwtSecret(),
          { expiresIn: "5m" },
        );
        res.json({ requiresTotp: true, totpSessionToken });
        return;
      }

      const token = generateToken(user.id, user.role, user.tokenVersion);
      const refreshToken = generateRefreshToken(user.id, user.tokenVersion);
      setSessionCookie(res, token);
      setRefreshCookie(res, user.id, user.tokenVersion);
      res.json({
        token,
        ...(refreshToken ? { refreshToken } : {}),
        user: { id: user.id, username: user.username, role: user.role },
      });
    } catch (err: unknown) {
      logger.error({ err }, "Login error");
      res.status(500).json({ error: "Login failed" });
    }
  });

  // ── TOTP 2FA routes ───────────────────────────────────────────────────────

  app.post("/api/auth/totp/verify", async (req: Request, res: Response): Promise<void> => {
    try {
      const { totpSessionToken, code } = req.body;
      if (!totpSessionToken || !code) {
        res.status(400).json({ error: "totpSessionToken and code are required" });
        return;
      }

      // DB-backed per-IP rate limit (shared across all replicas).
      const ip = getClientIp(req) ?? "unknown";
      const { allowed: ipAllowed } = await recordLoginAttempt(
        `totp:ip:${ip}`,
        MAX_TOTP_ATTEMPTS_PER_IP,
        TOTP_IP_WINDOW_MS,
      );
      if (!ipAllowed) {
        res.status(429).json({ error: "Too many verification attempts. Please try again later." });
        return;
      }

      // DB-backed per-pending-token failure limit (shared across all replicas).
      const tokenKey = getTotpTokenKey(totpSessionToken);
      const { allowed: tokenAllowed } = await checkLoginAttempts(tokenKey, MAX_TOTP_ATTEMPTS);
      if (!tokenAllowed) {
        res.status(429).json({ error: "Too many incorrect attempts. Please log in again." });
        return;
      }

      let payload: { userId: string; type: string; tokenVersion: number; exp?: number } | null = null;
      try {
        const decoded = jwt.verify(totpSessionToken, getJwtSecret());
        if (
          typeof decoded === "object" && decoded !== null &&
          "userId" in decoded && "type" in decoded &&
          (decoded as Record<string, unknown>).type === "totp-pending"
        ) {
          payload = decoded as { userId: string; type: string; tokenVersion: number; exp?: number };
        }
      } catch { /* invalid token */ }
      if (!payload) {
        res.status(401).json({ error: "Invalid or expired session. Please log in again." });
        return;
      }
      const user = await storage.getUser(payload.userId);
      if (!user || !user.totpEnabled || !user.totpSecret) {
        res.status(401).json({ error: "Invalid session." });
        return;
      }
      if (user.tokenVersion !== payload.tokenVersion) {
        res.status(401).json({ error: "Invalid or expired session. Please log in again." });
        return;
      }
      if (!verifyTotp(user.totpSecret, String(code))) {
        const { count: failures } = await recordLoginAttempt(tokenKey, MAX_TOTP_ATTEMPTS, TOTP_TOKEN_WINDOW_MS);
        const remaining = MAX_TOTP_ATTEMPTS - failures;
        if (remaining <= 0) {
          res.status(429).json({ error: "Too many incorrect attempts. Please log in again." });
        } else {
          res.status(400).json({ error: "Invalid code. Please check your authenticator app." });
        }
        return;
      }
      await clearLoginAttempts(tokenKey);
      const token = generateToken(user.id, user.role, user.tokenVersion);
      const refreshToken = generateRefreshToken(user.id, user.tokenVersion);
      setSessionCookie(res, token);
      setRefreshCookie(res, user.id, user.tokenVersion);
      res.json({
        token,
        ...(refreshToken ? { refreshToken } : {}),
        user: { id: user.id, username: user.username, role: user.role },
      });
    } catch (err: unknown) {
      logger.error({ err }, "TOTP verify error");
      res.status(500).json({ error: "Verification failed" });
    }
  });

  app.get("/api/auth/totp/status", authMiddleware, async (req: AuthRequest, res: Response): Promise<void> => {
    const user = await storage.getUser(req.userId!);
    if (!user) { res.status(401).json({ error: "User not found" }); return; }
    if (user.role !== "admin") { res.status(403).json({ error: "Admin only" }); return; }
    res.json({ enabled: user.totpEnabled ?? false });
  });

  app.post("/api/auth/totp/setup", authMiddleware, async (req: AuthRequest, res: Response): Promise<void> => {
    const user = await storage.getUser(req.userId!);
    if (!user) { res.status(401).json({ error: "User not found" }); return; }
    if (user.role !== "admin") { res.status(403).json({ error: "Admin only" }); return; }
    const { secret, uri } = generateTotpSecret();
    res.json({ secret, uri });
  });

  app.post("/api/auth/totp/enable", authMiddleware, async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const user = await storage.getUser(req.userId!);
      if (!user) { res.status(401).json({ error: "User not found" }); return; }
      if (user.role !== "admin") { res.status(403).json({ error: "Admin only" }); return; }
      const { secret, code } = req.body;
      if (!secret || !code) { res.status(400).json({ error: "secret and code are required" }); return; }
      if (!verifyTotp(String(secret), String(code))) {
        res.status(400).json({ error: "Invalid code. Please try again." });
        return;
      }
      await db.update(users).set({ totpSecret: secret, totpEnabled: true }).where(drizzleEq(users.id, req.userId!));
      logger.info({ userId: req.userId }, "Admin enabled TOTP 2FA");
      res.json({ ok: true });
    } catch (err: unknown) {
      logger.error({ err }, "TOTP enable error");
      res.status(500).json({ error: "Failed to enable 2FA" });
    }
  });

  app.post("/api/auth/totp/disable", authMiddleware, async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const user = await storage.getUser(req.userId!);
      if (!user) { res.status(401).json({ error: "User not found" }); return; }
      if (user.role !== "admin") { res.status(403).json({ error: "Admin only" }); return; }
      if (!user.totpEnabled || !user.totpSecret) {
        res.status(400).json({ error: "2FA is not enabled" }); return;
      }
      const { code } = req.body;
      if (!code) { res.status(400).json({ error: "code is required" }); return; }
      if (!verifyTotp(user.totpSecret, String(code))) {
        res.status(400).json({ error: "Invalid code. Please try again." });
        return;
      }
      await db.update(users).set({ totpSecret: null, totpEnabled: false }).where(drizzleEq(users.id, req.userId!));
      logger.info({ userId: req.userId }, "Admin disabled TOTP 2FA");
      res.json({ ok: true });
    } catch (err: unknown) {
      logger.error({ err }, "TOTP disable error");
      res.status(500).json({ error: "Failed to disable 2FA" });
    }
  });

  app.get("/api/auth/me", authMiddleware, async (req: AuthRequest, res: Response): Promise<void> => {
    const user = await storage.getUser(req.userId!);
    if (!user) {
      res.status(401).json({ error: "User not found" });
      return;
    }
    res.json({
      user: { id: user.id, username: user.username, role: user.role },
    });
  });

  app.delete("/api/auth/account", authMiddleware, async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const user = await storage.getUser(req.userId!);
      if (!user) {
        res.status(401).json({ error: "User not found" });
        return;
      }
      const { password } = req.body;
      if (!password) {
        res.status(400).json({ error: "Password is required to delete your account" });
        return;
      }
      const valid = await bcrypt.compare(password, user.password);
      if (!valid) {
        res.status(400).json({ error: "Incorrect password" });
        return;
      }
      await storage.deleteUser(user.id);
      logger.info({ userId: user.id }, "User deleted account");
      clearSessionCookie(res);
      clearRefreshCookie(res);
      res.json({ message: "Account deleted successfully" });
    } catch (err: unknown) {
      logger.error({ err }, "Delete account error");
      res.status(500).json({ error: "Failed to delete account" });
    }
  });

  app.patch("/api/auth/change-password", authMiddleware, async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const { currentPassword, newPassword } = req.body;
      if (!currentPassword || !newPassword) {
        res.status(400).json({ error: "Current password and new password are required" });
        return;
      }
      if (newPassword.length < 8) {
        res.status(400).json({ error: "New password must be at least 8 characters" });
        return;
      }
      const user = await storage.getUser(req.userId!);
      if (!user) {
        res.status(401).json({ error: "User not found" });
        return;
      }
      const valid = await bcrypt.compare(currentPassword, user.password);
      if (!valid) {
        res.status(400).json({ error: "Current password is incorrect" });
        return;
      }
      const hashed = await bcrypt.hash(newPassword, 10);
      const { tokenVersion } = await storage.updateUserPassword(user.id, hashed);
      logger.info({ userId: user.id }, "User changed password");
      const newToken = generateToken(user.id, user.role, tokenVersion);
      setSessionCookie(res, newToken);
      setRefreshCookie(res, user.id, tokenVersion);
      res.json({ message: "Password updated successfully", token: newToken });
    } catch (err: unknown) {
      logger.error({ err }, "Change password error");
      res.status(500).json({ error: "Failed to change password" });
    }
  });

  // ── POST /api/auth/forgot-password ───────────────────────────────────────
  app.post("/api/auth/forgot-password", async (req: Request, res: Response): Promise<void> => {
    const ALWAYS_OK = { message: "If that username exists and has an email on file, a reset code has been sent." };
    try {
      const ip = getClientIp(req);
      const { allowed } = await recordLoginAttempt(`forgot:${ip}`, 5, 15 * 60 * 1000);
      if (!allowed) {
        res.status(429).json({ error: "Too many attempts. Please try again later." });
        return;
      }
      const { username } = req.body;
      if (!username || typeof username !== "string") {
        res.json(ALWAYS_OK);
        return;
      }
      const user = await storage.getUserByUsername(username.trim().toLowerCase());
      if (!user || !user.email) {
        res.json(ALWAYS_OK);
        return;
      }
      // Per-user rate limit: max 3 codes per 5 min
      const { allowed: userAllowed } = await recordLoginAttempt(`forgot:uid:${user.id}`, 3, 5 * 60 * 1000);
      if (!userAllowed) {
        res.json(ALWAYS_OK);
        return;
      }
      const otp = String(crypto.randomInt(100000, 999999));
      const tokenHash = crypto.createHash("sha256").update(otp).digest("hex");
      const expiresAt = new Date(Date.now() + 15 * 60 * 1000);
      // Invalidate any prior unused tokens for this user
      await db
        .update(passwordResetTokens)
        .set({ usedAt: new Date() })
        .where(drizzleAnd(drizzleEq(passwordResetTokens.userId, user.id), drizzleIsNull(passwordResetTokens.usedAt)));
      await db.insert(passwordResetTokens).values({ userId: user.id, tokenHash, expiresAt });
      sendPasswordResetOTP({ to: user.email, username: user.username, otp });
      logger.info({ userId: user.id }, "Password reset OTP issued");
      res.json(ALWAYS_OK);
    } catch (err: unknown) {
      logger.error({ err }, "Forgot password error");
      res.json({ message: "If that username exists and has an email on file, a reset code has been sent." });
    }
  });

  // ── POST /api/auth/reset-password ─────────────────────────────────────────
  // Max wrong guesses before a reset token is burned.
  const MAX_RESET_ATTEMPTS = 5;

  app.post("/api/auth/reset-password", async (req: Request, res: Response): Promise<void> => {
    try {
      const ip = getClientIp(req);
      const { allowed } = await recordLoginAttempt(`resetpw:${ip}`, 10, 15 * 60 * 1000);
      if (!allowed) {
        res.status(429).json({ error: "Too many attempts. Please try again later." });
        return;
      }
      const { username, code, newPassword } = req.body;
      if (!username || !code || !newPassword) {
        res.status(400).json({ error: "Username, code, and new password are required" });
        return;
      }
      if (typeof newPassword !== "string" || newPassword.length < 8) {
        res.status(400).json({ error: "Password must be at least 8 characters" });
        return;
      }
      if (newPassword.length > 72) {
        res.status(400).json({ error: "Password must be 72 characters or fewer" });
        return;
      }
      const user = await storage.getUserByUsername(String(username).trim().toLowerCase());
      if (!user) {
        res.status(400).json({ error: "Invalid or expired code" });
        return;
      }
      const now = new Date();
      // Look up the active token by userId only — not by hash — so we can
      // track and limit wrong guesses regardless of which code is submitted.
      const [token] = await db
        .select()
        .from(passwordResetTokens)
        .where(
          drizzleAnd(
            drizzleEq(passwordResetTokens.userId, user.id),
            drizzleIsNull(passwordResetTokens.usedAt),
            drizzleGte(passwordResetTokens.expiresAt, now),
          ),
        )
        .limit(1);
      if (!token) {
        res.status(400).json({ error: "Invalid or expired code" });
        return;
      }
      const tokenHash = crypto.createHash("sha256").update(String(code).trim()).digest("hex");
      if (token.tokenHash !== tokenHash) {
        // Wrong code — atomically increment the failure counter in a single
        // UPDATE statement so concurrent requests cannot race past the limit.
        // The CASE expression burns the token (sets used_at) the moment
        // failed_attempts reaches the threshold, and the WHERE clause ensures
        // the UPDATE is a no-op if the token has already been burned.
        await db
          .update(passwordResetTokens)
          .set({
            failedAttempts: drizzleSql`failed_attempts + 1`,
            usedAt: drizzleSql`CASE WHEN failed_attempts + 1 >= ${MAX_RESET_ATTEMPTS} THEN NOW() ELSE used_at END`,
          })
          .where(
            drizzleAnd(
              drizzleEq(passwordResetTokens.id, token.id),
              drizzleIsNull(passwordResetTokens.usedAt),
              drizzleGte(passwordResetTokens.expiresAt, now),
              drizzleLt(passwordResetTokens.failedAttempts, MAX_RESET_ATTEMPTS),
            ),
          );
        res.status(400).json({ error: "Invalid or expired code" });
        return;
      }
      // Correct code — atomically consume the token.  The WHERE guards against
      // double-use if two concurrent correct submissions race each other.
      const [consumed] = await db
        .update(passwordResetTokens)
        .set({ usedAt: now })
        .where(
          drizzleAnd(
            drizzleEq(passwordResetTokens.id, token.id),
            drizzleIsNull(passwordResetTokens.usedAt),
            drizzleGte(passwordResetTokens.expiresAt, now),
          ),
        )
        .returning({ id: passwordResetTokens.id });
      if (!consumed) {
        res.status(400).json({ error: "Invalid or expired code" });
        return;
      }
      const hashed = await bcrypt.hash(newPassword, 10);
      await storage.updateUserPassword(user.id, hashed);
      logger.info({ userId: user.id }, "Password reset via OTP");
      res.json({ message: "Password reset successfully" });
    } catch (err: unknown) {
      logger.error({ err }, "Reset password error");
      res.status(500).json({ error: "Failed to reset password" });
    }
  });

  // ── POST /api/auth/refresh ────────────────────────────────────────────────
  // Exchanges a valid rid cookie for a new JWT + refreshed sid + rid cookies.
  // No credentials required — the signed rid cookie is the proof of identity.
  app.post("/api/auth/refresh", async (req: Request, res: Response): Promise<void> => {
    try {
      // Accept token from: signed rid cookie (browsers) OR body/header (mobile)
      const ridToken =
        (req.cookies?.[RID_COOKIE] as string | undefined) ||
        (req.body?.refreshToken as string | undefined) ||
        (req.headers?.["x-refresh-token"] as string | undefined);
      if (!ridToken) {
        res.status(401).json({ error: "No refresh token" }); return;
      }
      const payload = verifyRefreshToken(ridToken);
      if (!payload) {
        clearRefreshCookie(res);
        res.status(401).json({ error: "Invalid or expired refresh token" }); return;
      }
      const user = await storage.getUser(payload.userId);
      if (!user || user.tokenVersion !== payload.tokenVersion) {
        clearRefreshCookie(res);
        res.status(401).json({ error: "Session invalidated — please log in again" }); return;
      }
      const newToken = generateToken(user.id, user.role, user.tokenVersion);
      const newRefreshToken = generateRefreshToken(user.id, user.tokenVersion);
      setSessionCookie(res, newToken);
      setRefreshCookie(res, user.id, user.tokenVersion);
      res.json({
        token: newToken,
        ...(newRefreshToken ? { refreshToken: newRefreshToken } : {}),
        user: { id: user.id, username: user.username, role: user.role },
      });
    } catch (err: unknown) {
      logger.error({ err }, "Token refresh error");
      res.status(500).json({ error: "Token refresh failed" });
    }
  });
}
